import 'features/caregiver/screens/live_patient_overview_screen.dart';
import 'features/caregiver/screens/connected_patients_screen.dart';
import 'features/patient/screens/patient_connection_code_screen.dart';
import 'features/caregiver/screens/connect_patient_screen.dart';
import 'features/patient/screens/device_features_screen.dart';
import 'features/patient/screens/native_welcome_screen.dart';
import 'core/native/native_bootstrap.dart';
import 'core/native/smriti_native_services.dart';
import 'core/app/app_initializer.dart';
import 'features/patient/screens/patient_welcome_experience.dart';
import 'features/language/screens/language_voice_settings_screen.dart';
import 'features/language/screens/language_screen.dart';
import 'features/memory/screens/caregiver_memory_manager_screen.dart';
import 'features/rudas/screens/rudas_checkpoint_status_screen.dart';
import 'features/games/screens/caregiver_game_progress_screen.dart';
import 'features/patient/screens/patient_home_screen.dart';
import 'package:flutter/material.dart';
import 'core/backend/production_backend.dart';
import 'features/tasks/screens/patient_tasks_screen.dart';
import 'features/tasks/screens/caregiver_tasks_screen.dart';
import 'features/tasks/screens/caregiver_assign_task_screen.dart';
import 'features/notifications/screens/reminders_screen.dart';
import 'features/caregiver/screens/caregiver_home_screen.dart';

import 'core/theme/smriti_theme.dart';
import 'screens/splash_screen.dart';
import 'screens/welcome_screen.dart';
import 'screens/role_selection_screen.dart';
import 'screens/login_screen.dart';
import 'screens/patient/patient_dashboard.dart';
import 'screens/caregiver/caregiver_dashboard.dart';
import 'features/caregiver/screens/cloud_status_screen.dart';
import 'screens/register_screen.dart';
import 'features/rudas/screens/rudas_hand_jumble_screen.dart';
import 'features/device/device_features_screen.dart';
import 'features/rudas/screens/rudas_first_assessment_gate.dart';
import 'features/device/integration_status_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ProductionBackend.instance.initialize();
  await NativeBootstrap.initialize();
  await SmritiNativeServices.initialize();
  await AppInitializer.instance.initialize();
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SmritiAI());
}

class SmritiAI extends StatelessWidget {
  const SmritiAI({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SmritiAI',
      debugShowCheckedModeBanner: false,
      theme: SmritiTheme.light(),
      initialRoute: '/',
      routes: {
      '/integration-status': (context) =>
          const IntegrationStatusScreen(),

      '/rudas/first-assessment': (context) =>
          const RudasFirstAssessmentGate(),

      '/device-features': (context) =>
          const DeviceFeaturesScreen(),

      '/rudas/hand-jumble': (context) => RudasHandJumbleScreen(patientId: ModalRoute.of(context)?.settings.arguments as String? ?? 'current_patient'),

      '/register': (context) => const RegisterScreen(),
      '/patient/device-features': (context) => const DeviceFeaturesScreen(),
      '/patient/welcome-native': (context) => const NativeWelcomeScreen(),
      '/patient/games': (context) =>
          const GamesHubScreen(
            patientId: 'p1',
          ),
      '/patient/memories': (context) =>
          const MemoryAlbumScreen(
            patientId: 'p1',
          ),
      '/patient/mood': (context) =>
          const MoodScreen(
            patientId: 'p1',
          ),
      '/patient/progress': (context) =>
          const RudasCheckpointStatusScreen(
            patientId: 'p1',
          ),
      '/caregiver/game-progress': (context) =>
          const CaregiverGameProgressScreen(
            patientId: 'p1',
          ),
      '/caregiver/rudas-checkpoint': (context) =>
          const RudasCheckpointStatusScreen(
            patientId: 'p1',
          ),
      '/caregiver/memories': (context) =>
          const CaregiverMemoryManagerScreen(
            patientId: 'p1',
          ),

        '/': (context) => const SplashScreen(),
        '/welcome': (context) => const WelcomeScreen(),
        '/roles': (context) => const RoleSelectionScreen(),
        '/login': (context) => const LoginScreen(),

        // Main role dashboards.
        '/language': (context) =>
            const LanguageScreen(),
        '/language-voice': (context) =>
            const LanguageVoiceSettingsScreen(),
        '/patient/welcome-experience': (context) =>
            PatientWelcomeExperience(
              onContinue: () {
                Navigator.pushReplacementNamed(
                  context,
                  '/patient',
                );
              },
            ),
        '/patient': (context) =>
      '/patient/connection-code': (context) => const PatientConnectionCodeScreen(),
            const PatientHomeScreen(),
        '/caregiver': (context) =>
      '/caregiver/patients': (context) => const ConnectedPatientsScreen(),
      '/caregiver/connect-patient': (context) => const ConnectPatientScreen(),
            const CaregiverHomeScreen(),

        // Patient features.
        '/patient/tasks': (context) =>
            const PatientTasksScreen(),
        '/patient/reminders': (context) =>
            const RemindersScreen(),
        '/patient/rudas-checkpoint': (context) =>
            const RudasCheckpointStatusScreen(),

        // Caregiver features.
        '/caregiver/tasks': (context) =>
            CaregiverTasksScreen(
              patientId:
                  UserContext.patientIdForCaregiver,
            ),
        '/caregiver/assign-task': (context) {
          final args =
              ModalRoute.of(context)?.settings.arguments;

          return CaregiverAssignTaskScreen(
            patientId: args is String
                ? args
                : UserContext.patientIdForCaregiver,
          );
        },
        '/caregiver/reminders': (context) =>
            const RemindersScreen(
              caregiverMode: true,
            ),
        '/caregiver/game-progress': (context) =>
            CaregiverGameProgressScreen(
              patientId:
                  UserContext.patientIdForCaregiver,
            ),
        '/caregiver/memories': (context) =>
            CaregiverMemoryManagerScreen(
              patientId:
                  UserContext.patientIdForCaregiver,
            ),
        '/caregiver/rudas-checkpoint': (context) =>
            RudasCheckpointStatusScreen(
              patientId:
                  UserContext.patientIdForCaregiver,
            ),
      },
    );
  }
}
