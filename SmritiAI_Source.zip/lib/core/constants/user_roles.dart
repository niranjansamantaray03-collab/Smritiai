enum UserRole {
  patient,
  caregiver,
}
