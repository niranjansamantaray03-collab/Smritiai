
import 'dart:io';

import '../../memory/services/native_memory_media_controller.dart';

import 'package:uuid/uuid.dart';

import '../../../core/auth/user_context.dart';
import '../../../data/persistence/feature_persistence_gateway.dart';
import '../../../data/remote/supabase_data_service.dart';

class MemoryMediaUploadController {
  MemoryMediaUploadController._();

  static final MemoryMediaUploadController instance =
      MemoryMediaUploadController._();

  final _cloud = SupabaseDataService.instance;
  final _gateway = FeaturePersistenceGateway.instance;
  final _media = NativeMemoryMediaController.instance;

  String get patientId =>
      UserContext.patientIdForCurrentUser ??
      UserContext.userId ??
      'current_patient';

  
Future<File?> uploadPhotoFromGallery() async {
    final file =
        await _media.selectPhoto();

    if (file == null) return null;

    await uploadPhoto(file: file);
    return file;
  }

  Future<File?> uploadPhotoFromCamera() async {
    final file =
        await _media.capturePhoto();

    if (file == null) return null;

    await uploadPhoto(file: file);
    return file;
  }

  Future<Map<String, dynamic>?> uploadPhoto({
    required File file,
    String? title,
    String? description,
  }) async {
    final id = const Uuid().v4();

    final localRecord = {
      'id': id,
      'patient_id': patientId,
      'media_type': 'photo',
      'local_path': file.path,
      'title': title ?? 'Memory photo',
      'description': description ?? '',
      'created_at': DateTime.now().toIso8601String(),
      'sync_status': 'pending',
    };

    await _gateway.saveRecord(
      collection: 'memory_media',
      recordId: id,
      patientId: patientId,
      data: localRecord,
    );

    try {
      final result = await _cloud.uploadMemoryMedia(
        patientId: patientId,
        file: file,
        mediaType: 'photo',
        title: title,
        description: description,
      );

      if (result != null) {
        await _gateway.saveRecord(
          collection: 'memory_media',
          recordId: id,
          patientId: patientId,
          data: {
            ...localRecord,
            ...result,
            'id': id,
            'patient_id': patientId,
            'sync_status': 'synced',
          },
        );
      }

      return result;
    } catch (_) {
      // The local record remains queued for later sync.
      return null;
    }
  }
}
