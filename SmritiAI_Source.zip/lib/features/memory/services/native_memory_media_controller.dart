
import 'dart:io';

import 'package:image_picker/image_picker.dart';

import 'native_photo_service.dart';

class NativeMemoryMediaController {
  NativeMemoryMediaController._();

  static final NativeMemoryMediaController instance =
      NativeMemoryMediaController._();

  final NativePhotoService _photos =
      NativePhotoService.instance;

  Future<File?> selectPhoto() async {
    final XFile? photo = await _photos.pickFromGallery();

    if (photo == null) return null;

    return File(photo.path);
  }

  Future<File?> capturePhoto() async {
    final XFile? photo = await _photos.takePhoto();

    if (photo == null) return null;

    return File(photo.path);
  }
}
