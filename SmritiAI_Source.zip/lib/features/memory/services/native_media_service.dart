import 'dart:io';

import 'package:image_picker/image_picker.dart';

class NativeMediaService {
  NativeMediaService._();

  static final NativeMediaService instance = NativeMediaService._();

  final ImagePicker _picker = ImagePicker();

  Future<File?> pickPhoto() async {
    final result = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 85,
      maxWidth: 2000,
    );

    return result == null ? null : File(result.path);
  }

  Future<File?> takePhoto() async {
    final result = await _picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 85,
      maxWidth: 2000,
    );

    return result == null ? null : File(result.path);
  }
}
