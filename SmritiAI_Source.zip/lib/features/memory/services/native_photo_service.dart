
import 'package:image_picker/image_picker.dart';

class NativePhotoService {
  NativePhotoService._();

  static final NativePhotoService instance =
      NativePhotoService._();

  final ImagePicker _picker = ImagePicker();

  Future<XFile?> pickFromGallery() {
    return _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 85,
    );
  }

  Future<XFile?> takePhoto() {
    return _picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 85,
    );
  }
}
