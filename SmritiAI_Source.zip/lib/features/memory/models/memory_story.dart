class MemoryStory {
  final String id;
  final String patientId;
  final String title;
  final String story;
  final String? imageUrl;
  final DateTime createdAt;
  final List<String> tags;

  const MemoryStory({
    required this.id,
    required this.patientId,
    required this.title,
    required this.story,
    this.imageUrl,
    required this.createdAt,
    this.tags = const [],
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'patientId': patientId,
      'title': title,
      'story': story,
      'imageUrl': imageUrl,
      'createdAt': createdAt.toIso8601String(),
      'tags': tags,
    };
  }
}
