
enum RecallType {
  independent,
  cued,
}

class StoryRecallEvent {
  final String id;
  final String patientId;
  final String storyId;
  final DateTime createdAt;
  final RecallType type;
  final bool successful;
  final String? response;

  const StoryRecallEvent({
    required this.id,
    required this.patientId,
    required this.storyId,
    required this.createdAt,
    required this.type,
    required this.successful,
    this.response,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'patient_id': patientId,
    'story_id': storyId,
    'created_at': createdAt.toIso8601String(),
    'recall_type': type.name,
    'successful': successful,
    'response': response,
  };
}
