
enum MemoryMediaType {
  photo,
  audio,
}

class MemoryMedia {
  final String id;
  final String patientId;
  final String? storyId;
  final MemoryMediaType type;
  final String title;
  final String? localPath;
  final String? remoteUrl;
  final String? thumbnailUrl;
  final DateTime createdAt;
  final String? uploadedBy;

  const MemoryMedia({
    required this.id,
    required this.patientId,
    this.storyId,
    required this.type,
    required this.title,
    this.localPath,
    this.remoteUrl,
    this.thumbnailUrl,
    required this.createdAt,
    this.uploadedBy,
  });

  bool get isPhoto =>
      type == MemoryMediaType.photo;

  bool get isAudio =>
      type == MemoryMediaType.audio;

  String? get usableUrl =>
      remoteUrl ?? localPath;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'patient_id': patientId,
      'story_id': storyId,
      'type': type.name,
      'title': title,
      'local_path': localPath,
      'remote_url': remoteUrl,
      'thumbnail_url': thumbnailUrl,
      'created_at': createdAt.toIso8601String(),
      'uploaded_by': uploadedBy,
    };
  }

  factory MemoryMedia.fromMap(
    Map<String, dynamic> map,
  ) {
    return MemoryMedia(
      id: map['id'] as String? ?? '',
      patientId:
          map['patient_id'] as String? ?? '',
      storyId:
          map['story_id'] as String?,
      type: MemoryMediaType.values.firstWhere(
        (value) =>
            value.name ==
            (map['type'] as String? ?? 'photo'),
        orElse: () =>
            MemoryMediaType.photo,
      ),
      title:
          map['title'] as String? ?? '',
      localPath:
          map['local_path'] as String?,
      remoteUrl:
          map['remote_url'] as String?,
      thumbnailUrl:
          map['thumbnail_url'] as String?,
      createdAt:
          DateTime.tryParse(
                map['created_at']
                        as String? ??
                    '',
              ) ??
              DateTime.now(),
      uploadedBy:
          map['uploaded_by'] as String?,
    );
  }
}
