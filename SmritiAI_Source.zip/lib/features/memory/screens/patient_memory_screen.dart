import 'package:flutter/material.dart';

import '../models/memory_photo.dart';
import '../services/memory_service.dart';
import 'memory_story_view_screen.dart';

class PatientMemoryScreen extends StatefulWidget {
  final String patientId;

  const PatientMemoryScreen({
    super.key,
    required this.patientId,
  });

  @override
  State<PatientMemoryScreen> createState() =>
      _PatientMemoryScreenState();
}

class _PatientMemoryScreenState
    extends State<PatientMemoryScreen> {
  final MemoryService _service = MemoryService.instance;

  @override
  Widget build(BuildContext context) {
    final stories = _service.getStories(widget.patientId);
    final photos = _service.getPhotos(widget.patientId);

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Memories'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '💛 My Memories',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Photos and stories shared by your caregiver.',
                    style: TextStyle(fontSize: 18),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          const Text(
            '📖 Memory Stories',
            style: TextStyle(
              fontSize: 23,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 10),

          if (stories.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                  'Your caregiver has not added a memory story yet.',
                  style: TextStyle(fontSize: 18),
                ),
              ),
            )
          else
            ...stories.map(
              (story) => Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: ListTile(
                  contentPadding: const EdgeInsets.all(16),
                  leading: const CircleAvatar(
                    radius: 27,
                    child: Icon(Icons.auto_stories, size: 28),
                  ),
                  title: Text(
                    story.title,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  subtitle: Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(
                      story.story,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 16),
                    ),
                  ),
                  trailing: const Icon(
                    Icons.chevron_right,
                    size: 30,
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => MemoryStoryViewScreen(
                          patientId: widget.patientId,
                          storyId: story.id,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),

          const SizedBox(height: 20),

          const Text(
            '🖼️ Memory Album',
            style: TextStyle(
              fontSize: 23,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 10),

          if (photos.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                  'Your caregiver has not added photos yet.',
                  style: TextStyle(fontSize: 18),
                ),
              ),
            )
          else
            _photoGrid(photos),
        ],
      ),
    );
  }

  Widget _photoGrid(List<MemoryPhoto> photos) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: photos.length,
      gridDelegate:
          const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 0.9,
      ),
      itemBuilder: (context, index) {
        final photo = photos[index];

        return Card(
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: () {
              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: Text(photo.title),
                  content: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _image(photo),
                        if (photo.description != null &&
                            photo.description!.isNotEmpty) ...[
                          const SizedBox(height: 12),
                          Text(
                            photo.description!,
                            style: const TextStyle(fontSize: 17),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              );
            },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(
                  child: _image(photo),
                ),
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Text(
                    photo.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _image(MemoryPhoto photo) {
    if (photo.imageUrl.isEmpty) {
      return const Center(
        child: Icon(
          Icons.photo,
          size: 50,
        ),
      );
    }

    return Image.network(
      photo.imageUrl,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) {
        return const Center(
          child: Icon(
            Icons.broken_image,
            size: 50,
          ),
        );
      },
    );
  }
}
