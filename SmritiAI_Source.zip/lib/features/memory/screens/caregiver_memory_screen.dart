import 'package:flutter/material.dart';

import '../models/memory_photo.dart';
import '../models/../../memory/models/memory_story.dart';
import '../services/memory_service.dart';

class CaregiverMemoryScreen extends StatefulWidget {
  final String patientId;
  final String patientName;

  const CaregiverMemoryScreen({
    super.key,
    required this.patientId,
    required this.patientName,
  });

  @override
  State<CaregiverMemoryScreen> createState() =>
      _CaregiverMemoryScreenState();
}

class _CaregiverMemoryScreenState
    extends State<CaregiverMemoryScreen> {
  final MemoryService _service = MemoryService.instance;

  final _storyTitleController = TextEditingController();
  final _storyController = TextEditingController();
  final _storyImageController = TextEditingController();
  final _tagsController = TextEditingController();

  final _photoTitleController = TextEditingController();
  final _photoUrlController = TextEditingController();
  final _photoDescriptionController = TextEditingController();
  final _peopleController = TextEditingController();
  final _locationController = TextEditingController();

  @override
  void dispose() {
    _storyTitleController.dispose();
    _storyController.dispose();
    _storyImageController.dispose();
    _tagsController.dispose();
    _photoTitleController.dispose();
    _photoUrlController.dispose();
    _photoDescriptionController.dispose();
    _peopleController.dispose();
    _locationController.dispose();
    super.dispose();
  }

  Future<void> _addStory() async {
    _storyTitleController.clear();
    _storyController.clear();
    _storyImageController.clear();
    _tagsController.clear();

    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Add Memory Story'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: _storyTitleController,
                decoration: const InputDecoration(
                  labelText: 'Story title',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _storyController,
                maxLines: 6,
                decoration: const InputDecoration(
                  labelText: 'Memory story',
                  alignLabelWithHint: true,
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _storyImageController,
                decoration: const InputDecoration(
                  labelText: 'Photo URL (optional)',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _tagsController,
                decoration: const InputDecoration(
                  labelText: 'Tags',
                  hintText: 'family, school, childhood',
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final title =
                  _storyTitleController.text.trim();
              final story =
                  _storyController.text.trim();

              if (title.isEmpty || story.isEmpty) {
                return;
              }

              _service.addStory(
                MemoryStory(
                  id: 'story_${DateTime.now().millisecondsSinceEpoch}',
                  patientId: widget.patientId,
                  title: title,
                  story: story,
                  imageUrl:
                      _storyImageController.text.trim().isEmpty
                          ? null
                          : _storyImageController.text.trim(),
                  createdAt: DateTime.now(),
                  tags: _tagsController.text
                      .split(',')
                      .map((tag) => tag.trim())
                      .where((tag) => tag.isNotEmpty)
                      .toList(),
                ),
              );

              Navigator.pop(context);
              setState(() {});
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<void> _addPhoto() async {
    _photoTitleController.clear();
    _photoUrlController.clear();
    _photoDescriptionController.clear();
    _peopleController.clear();
    _locationController.clear();

    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Add Memory Photo'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: _photoTitleController,
                decoration: const InputDecoration(
                  labelText: 'Photo title',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _photoUrlController,
                decoration: const InputDecoration(
                  labelText: 'Photo URL',
                  hintText: 'Cloud image URL',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _photoDescriptionController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Description',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _peopleController,
                decoration: const InputDecoration(
                  labelText: 'People',
                  hintText: 'Mother, Brother, Friend',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _locationController,
                decoration: const InputDecoration(
                  labelText: 'Location',
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final title =
                  _photoTitleController.text.trim();

              if (title.isEmpty) {
                return;
              }

              _service.addPhoto(
                MemoryPhoto(
                  id: 'photo_${DateTime.now().millisecondsSinceEpoch}',
                  patientId: widget.patientId,
                  title: title,
                  imageUrl:
                      _photoUrlController.text.trim(),
                  description:
                      _photoDescriptionController.text.trim().isEmpty
                          ? null
                          : _photoDescriptionController.text.trim(),
                  createdAt: DateTime.now(),
                  people: _peopleController.text
                      .split(',')
                      .map((person) => person.trim())
                      .where((person) => person.isNotEmpty)
                      .toList(),
                  location:
                      _locationController.text.trim().isEmpty
                          ? null
                          : _locationController.text.trim(),
                ),
              );

              Navigator.pop(context);
              setState(() {});
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _deleteStory(String id) {
    _service.deleteStory(
      widget.patientId,
      id,
    );
    setState(() {});
  }

  void _deletePhoto(String id) {
    _service.deletePhoto(
      widget.patientId,
      id,
    );
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final stories = _service.getStories(widget.patientId);
    final photos = _service.getPhotos(widget.patientId);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Memory Manager'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(
            'Memories for ${widget.patientName}',
            style: const TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 18),

          Row(
            children: [
              Expanded(
                child: _stat(
                  'Stories',
                  stories.length,
                  Icons.auto_stories,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _stat(
                  'Photos',
                  photos.length,
                  Icons.photo_library,
                ),
              ),
            ],
          ),

          const SizedBox(height: 22),

          SizedBox(
            height: 62,
            child: ElevatedButton.icon(
              onPressed: _addStory,
              icon: const Icon(Icons.menu_book, size: 28),
              label: const Text(
                'Add Memory Story',
                style: TextStyle(fontSize: 18),
              ),
            ),
          ),

          const SizedBox(height: 12),

          SizedBox(
            height: 62,
            child: OutlinedButton.icon(
              onPressed: _addPhoto,
              icon: const Icon(Icons.add_a_photo, size: 28),
              label: const Text(
                'Add Memory Photo',
                style: TextStyle(fontSize: 18),
              ),
            ),
          ),

          const SizedBox(height: 24),

          const Text(
            'Stories',
            style: TextStyle(
              fontSize: 23,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 10),

          ...stories.map(
            (story) => Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                title: Text(
                  story.title,
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Text(
                  story.story,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => _deleteStory(story.id),
                ),
              ),
            ),
          ),

          const SizedBox(height: 18),

          const Text(
            'Photos',
            style: TextStyle(
              fontSize: 23,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 10),

          ...photos.map(
            (photo) => Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: const Icon(
                  Icons.photo,
                  size: 32,
                ),
                title: Text(
                  photo.title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Text(
                  photo.description ?? 'No description',
                ),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => _deletePhoto(photo.id),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _stat(
    String title,
    int value,
    IconData icon,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          children: [
            Icon(icon, size: 31),
            const SizedBox(height: 5),
            Text(
              '$value',
              style: const TextStyle(
                fontSize: 27,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(title),
          ],
        ),
      ),
    );
  }
}
