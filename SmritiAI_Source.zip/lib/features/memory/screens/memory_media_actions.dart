import 'dart:io';

import 'package:flutter/material.dart';

import '../services/native_media_service.dart';

class MemoryMediaActions extends StatelessWidget {
  final void Function(File file) onSelected;

  const MemoryMediaActions({
    super.key,
    required this.onSelected,
  });

  Future<void> choose(BuildContext context) async {
    final source = await showModalBottomSheet<String>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              minTileHeight: 68,
              leading: const Icon(Icons.photo_library_rounded),
              title: const Text(
                'Choose from gallery',
                style: TextStyle(fontSize: 20),
              ),
              onTap: () => Navigator.pop(context, 'gallery'),
            ),
            ListTile(
              minTileHeight: 68,
              leading: const Icon(Icons.camera_alt_rounded),
              title: const Text(
                'Take a photo',
                style: TextStyle(fontSize: 20),
              ),
              onTap: () => Navigator.pop(context, 'camera'),
            ),
          ],
        ),
      ),
    );

    if (source == null) return;

    final service = NativeMediaService.instance;

    final File? file = source == 'camera'
        ? await service.takePhoto()
        : await service.pickPhoto();

    if (file != null) {
      onSelected(file);
    }
  }

  @override
  Widget build(BuildContext context) {
    return FilledButton.icon(
      style: FilledButton.styleFrom(
        minimumSize: const Size.fromHeight(60),
      ),
      onPressed: () => choose(context),
      icon: const Icon(Icons.add_a_photo_rounded),
      label: const Text(
        'Add a memory photo',
        style: TextStyle(fontSize: 20),
      ),
    );
  }
}
