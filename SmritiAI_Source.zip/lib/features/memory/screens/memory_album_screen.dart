
import 'package:flutter/material.dart';

import '../../../core/auth/user_context.dart';
import '../models/memory_person.dart';
import '../models/memory_story.dart';
import '../services/memory_service.dart';
import 'memory_people_screen.dart';
import 'story_recall_screen.dart';

class MemoryAlbumScreen extends StatefulWidget {
  final String? patientId;

  const MemoryAlbumScreen({
    super.key,
    this.patientId,
  });

  @override
  State<MemoryAlbumScreen> createState() =>
      _MemoryAlbumScreenState();
}

class _MemoryAlbumScreenState
    extends State<MemoryAlbumScreen> {

  late String _patientId;

  @override
  void initState() {
    super.initState();

    _patientId =
        widget.patientId ??
        UserContext.patientIdForCurrentUser ??
        UserContext.patientIdForCaregiver ??
        'p1';
  }

  @override
  Widget build(BuildContext context) {
    final stories =
        MemoryService.instance.getStories(_patientId);

    final people =
        MemoryService.instance.getPeople(_patientId);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'My Memories',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () async => setState(() {}),
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            _introCard(),
            const SizedBox(height: 18),

            _sectionHeader(
              'People I Know',
              'Family and familiar people',
              Icons.people_outline,
              () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => MemoryPeopleScreen(
                      patientId: _patientId,
                    ),
                  ),
                ).then((_) => setState(() {}));
              },
            ),

            const SizedBox(height: 10),

            if (people.isEmpty)
              _emptyCard(
                Icons.person_add_alt_1,
                'No people added yet',
                'Your caregiver can add family members and '
                    'important people here.',
              )
            else
              ...people.take(4).map(
                (person) => _personTile(person),
              ),

            const SizedBox(height: 22),

            _sectionHeader(
              'Memory Stories',
              'Special moments from your life',
              Icons.auto_stories_outlined,
              null,
            ),

            const SizedBox(height: 10),

            if (stories.isEmpty)
              _emptyCard(
                Icons.menu_book_outlined,
                'No stories yet',
                'Your caregiver can create personal stories '
                    'using meaningful memories.',
              )
            else
              ...stories.map(
                (story) => _storyCard(story),
              ),

            const SizedBox(height: 22),

            Card(
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => StoryRecallScreen(
                        patientId: _patientId,
                      ),
                    ),
                  );
                },
                child: const Padding(
                  padding: EdgeInsets.all(20),
                  child: Row(
                    children: [
                      Icon(
                        Icons.psychology_alt_outlined,
                        size: 38,
                      ),
                      SizedBox(width: 15),
                      Expanded(
                        child: Column(
                          crossAxisAlignment:
                              CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Remember Together',
                              style: TextStyle(
                                fontSize: 19,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 5),
                            Text(
                              'Look at a story and talk about '
                              'the memory.',
                              style: TextStyle(fontSize: 15),
                            ),
                          ],
                        ),
                      ),
                      Icon(Icons.chevron_right),
                    ],
                  ),
                ),
              ),
            ),

            const SizedBox(height: 16),

            const Card(
              child: Padding(
                padding: EdgeInsets.all(18),
                child: Row(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.favorite_outline),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Memories are here to support connection '
                        'and conversation. A forgotten detail is '
                        'not a failure.',
                        style: TextStyle(fontSize: 15),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _introCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          children: [
            const Icon(
              Icons.photo_album_outlined,
              size: 52,
            ),
            const SizedBox(height: 12),
            const Text(
              'A place for special memories',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 23,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Photos, people and stories can help keep '
              'familiar moments close.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionHeader(
    String title,
    String subtitle,
    IconData icon,
    VoidCallback? onTap,
  ) {
    return Row(
      children: [
        Icon(icon, size: 28),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                subtitle,
                style: const TextStyle(fontSize: 13),
              ),
            ],
          ),
        ),
        if (onTap != null)
          IconButton(
            onPressed: onTap,
            icon: const Icon(Icons.arrow_forward),
          ),
      ],
    );
  }

  Widget _personTile(MemoryPerson person) {
    return Card(
      child: ListTile(
        leading: const CircleAvatar(
          child: Icon(Icons.person),
        ),
        title: Text(
          person.name,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Text(
          person.relationship.isEmpty
              ? 'Familiar person'
              : person.relationship,
        ),
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }

  Widget _storyCard(MemoryStory story) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => StoryRecallScreen(
                patientId: _patientId,
                initialStoryId: story.id,
              ),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(17),
          child: Row(
            children: [
              Container(
                width: 62,
                height: 62,
                decoration: BoxDecoration(
                  borderRadius:
                      BorderRadius.circular(14),
                ),
                child: story.imageUrl.isEmpty
                    ? const Icon(
                        Icons.auto_stories,
                        size: 32,
                      )
                    : ClipRRect(
                        borderRadius:
                            BorderRadius.circular(14),
                        child: Image.network(
                          story.imageUrl,
                          fit: BoxFit.cover,
                          errorBuilder:
                              (_, __, ___) =>
                                  const Icon(
                            Icons.auto_stories,
                            size: 32,
                          ),
                        ),
                      ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    Text(
                      story.title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      story.story,
                      maxLines: 2,
                      overflow:
                          TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              const Icon(Icons.play_circle_outline),
            ],
          ),
        ),
      ),
    );
  }

  Widget _emptyCard(
    IconData icon,
    String title,
    String subtitle,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          children: [
            Icon(icon, size: 38),
            const SizedBox(height: 10),
            Text(
              title,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 5),
            Text(
              subtitle,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
