
import 'dart:io';

import 'package:flutter/material.dart';

import '../services/memory_media_upload_controller.dart';

class MemoryPhotoActionsCard extends StatefulWidget {
  const MemoryPhotoActionsCard({
    super.key,
  });

  @override
  State<MemoryPhotoActionsCard> createState() =>
      _MemoryPhotoActionsCardState();
}

class _MemoryPhotoActionsCardState
    extends State<MemoryPhotoActionsCard> {

  bool busy = false;
  String status = '';

  Future<void> _choose() async {
    await _run(
      () => MemoryMediaUploadController.instance
          .uploadPhotoFromGallery(),
    );
  }

  Future<void> _camera() async {
    await _run(
      () => MemoryMediaUploadController.instance
          .uploadPhotoFromCamera(),
    );
  }

  Future<void> _run(Future<File?> Function() action) async {
    setState(() {
      busy = true;
      status = 'Opening camera...';
    });

    try {
      final file = await action();

      if (!mounted) return;

      setState(() {
        busy = false;
        status = file == null
            ? 'No photo selected.'
            : 'Memory photo saved.';
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        busy = false;
        status = 'Photo could not be saved.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.photo_album, size: 32),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Add a memory',
                    style: TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 8),

            const Text(
              'Add a familiar photo from the phone or camera.',
              style: TextStyle(fontSize: 16),
            ),

            const SizedBox(height: 14),

            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: busy ? null : _camera,
                    icon: const Icon(Icons.camera_alt),
                    label: const Padding(
                      padding: EdgeInsets.all(12),
                      child: Text(
                        'Camera',
                        style: TextStyle(fontSize: 17),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: busy ? null : _choose,
                    icon: const Icon(Icons.photo_library),
                    label: const Padding(
                      padding: EdgeInsets.all(12),
                      child: Text(
                        'Gallery',
                        style: TextStyle(fontSize: 17),
                      ),
                    ),
                  ),
                ),
              ],
            ),

            if (busy || status.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text(
                status,
                style: const TextStyle(fontSize: 15),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
