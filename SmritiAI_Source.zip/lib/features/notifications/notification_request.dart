
class NotificationRequest {
  final int id;
  final String title;
  final String body;
  final DateTime scheduledAt;
  final bool recurring;
  final String? payload;

  const NotificationRequest({
    required this.id,
    required this.title,
    required this.body,
    required this.scheduledAt,
    this.recurring = false,
    this.payload,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'body': body,
      'scheduled_at':
          scheduledAt.toIso8601String(),
      'recurring': recurring,
      'payload': payload,
    };
  }
}
