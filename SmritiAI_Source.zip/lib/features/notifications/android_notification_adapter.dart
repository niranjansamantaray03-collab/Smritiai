
import 'reminder.dart';

abstract class AndroidNotificationAdapter {
  Future<void> initialize();

  Future<bool> requestPermission();

  Future<void> scheduleOnce(
    SmritiReminder reminder,
  );

  Future<void> scheduleDaily(
    SmritiReminder reminder,
  );

  Future<void> scheduleWeekly(
    SmritiReminder reminder,
  );

  Future<void> cancel(
    String reminderId,
  );

  Future<void> cancelAll();
}

/*
 Production Android implementation:

 - flutter_local_notifications
 - Android 13+ POST_NOTIFICATIONS permission
 - Android notification channel
 - timezone-aware scheduling
 - exact alarm handling where required
 - boot rescheduling
 - notification tap deep links
 - recurring daily/weekly scheduling

 The application layer does not depend directly on the
 plugin, keeping the architecture replaceable.
*/
