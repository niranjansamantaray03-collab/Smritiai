
import 'package:flutter/material.dart';

import '../../../core/auth/user_context.dart';
import '../reminder.dart';
import '../reminder_controller.dart';
import '../reminder_service.dart';

class RemindersScreen
    extends StatefulWidget {
  const RemindersScreen({
    super.key,
    this.patientId,
  });

  final String? patientId;

  @override
  State<RemindersScreen> createState() =>
      _RemindersScreenState();
}

class _RemindersScreenState
    extends State<RemindersScreen> {
  late final ReminderController
      _controller;

  String get _patientId =>
      widget.patientId ??
      UserContext.patientIdForCurrentUser ??
      'p1';

  @override
  void initState() {
    super.initState();

    _controller =
        ReminderController(
      patientId: _patientId,
    );

    _controller.load();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _addReminder() async {
    final titleController =
        TextEditingController();

    final descriptionController =
        TextEditingController();

    ReminderRepeat repeat =
        ReminderRepeat.once;

    final result =
        await showDialog<bool>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder:
              (context, setDialogState) {
            return AlertDialog(
              title: const Text(
                'Create reminder',
              ),
              content:
                  SingleChildScrollView(
                child: Column(
                  mainAxisSize:
                      MainAxisSize.min,
                  children: [
                    TextField(
                      controller:
                          titleController,
                      decoration:
                          const InputDecoration(
                        labelText: 'Reminder',
                      ),
                    ),
                    const SizedBox(
                      height: 12,
                    ),
                    TextField(
                      controller:
                          descriptionController,
                      decoration:
                          const InputDecoration(
                        labelText:
                            'Message',
                      ),
                    ),
                    const SizedBox(
                      height: 12,
                    ),
                    DropdownButtonFormField<
                        ReminderRepeat>(
                      value: repeat,
                      decoration:
                          const InputDecoration(
                        labelText:
                            'Repeat',
                      ),
                      items: ReminderRepeat
                          .values
                          .map(
                            (value) =>
                                DropdownMenuItem(
                              value: value,
                              child: Text(
                                value.name
                                    .toUpperCase(),
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (value) {
                        if (value !=
                            null) {
                          setDialogState(
                            () =>
                                repeat =
                                    value,
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () =>
                      Navigator.pop(
                    context,
                    false,
                  ),
                  child: const Text(
                    'Cancel',
                  ),
                ),
                FilledButton(
                  onPressed: () =>
                      Navigator.pop(
                    context,
                    true,
                  ),
                  child: const Text(
                    'Save',
                  ),
                ),
              ],
            );
          },
        );
      },
    );

    if (result != true) return;

    if (titleController.text
        .trim()
        .isEmpty) {
      return;
    }

    await ReminderService.instance
        .create(
      patientId: _patientId,
      caregiverId:
          UserContext.userId,
      title:
          titleController.text.trim(),
      description:
          descriptionController.text
              .trim(),
      scheduledAt:
          DateTime.now().add(
        const Duration(minutes: 1),
      ),
      repeat: repeat,
      kind: ReminderKind.custom,
    );

    await _controller.load();

    titleController.dispose();
    descriptionController.dispose();
  }

  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Reminders',
        ),
      ),
      floatingActionButton:
          FloatingActionButton.extended(
        onPressed: _addReminder,
        icon: const Icon(
          Icons.add_alert,
        ),
        label: const Text(
          'Add reminder',
        ),
      ),
      body: AnimatedBuilder(
        animation: _controller,
        builder: (_, __) {
          if (_controller.loading) {
            return const Center(
              child:
                  CircularProgressIndicator(),
            );
          }

          if (_controller
              .reminders.isEmpty) {
            return const Center(
              child: Padding(
                padding:
                    EdgeInsets.all(24),
                child: Text(
                  'No active reminders yet.',
                  textAlign:
                      TextAlign.center,
                ),
              ),
            );
          }

          return ListView.builder(
            padding:
                const EdgeInsets.all(16),
            itemCount:
                _controller
                    .reminders.length,
            itemBuilder:
                (context, index) {
              final reminder =
                  _controller
                      .reminders[index];

              return Card(
                child: ListTile(
                  leading: const CircleAvatar(
                    child: Icon(
                      Icons.notifications,
                    ),
                  ),
                  title: Text(
                    reminder.title,
                  ),
                  subtitle: Text(
                    '${reminder.description}\n'
                    '${reminder.repeat.name}',
                  ),
                  isThreeLine: true,
                  trailing: PopupMenuButton(
                    onSelected:
                        (value) async {
                      if (value ==
                          'disable') {
                        await _controller
                            .disable(
                          reminder.id,
                        );
                      }

                      if (value ==
                          'delete') {
                        await _controller
                            .delete(
                          reminder.id,
                        );
                      }
                    },
                    itemBuilder:
                        (_) => const [
                      PopupMenuItem(
                        value:
                            'disable',
                        child: Text(
                          'Disable',
                        ),
                      ),
                      PopupMenuItem(
                        value:
                            'delete',
                        child: Text(
                          'Delete',
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
