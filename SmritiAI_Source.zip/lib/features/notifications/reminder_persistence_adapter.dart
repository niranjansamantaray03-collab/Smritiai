
import '../../data/persistence/feature_write_service.dart';
import 'reminder.dart';

class ReminderPersistenceAdapter {
  ReminderPersistenceAdapter._();

  static final ReminderPersistenceAdapter instance =
      ReminderPersistenceAdapter._();

  Future<void> save(SmritiReminder reminder) {
    return FeatureWriteService.instance.saveReminder(reminder);
  }
}
