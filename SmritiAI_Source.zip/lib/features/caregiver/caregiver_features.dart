class CaregiverFeatures {
  static const List<String> available = [
    'My Patients',
    'Connect Patient',
    'Assign Tasks',
    'Reminders',
    'Cognitive Progress',
    'RUDAS Progress',
    'Memory Stories',
    'Mood',
  ];
}
