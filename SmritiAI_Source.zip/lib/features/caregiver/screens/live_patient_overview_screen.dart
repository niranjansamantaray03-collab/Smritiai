
import 'package:flutter/material.dart';

import '../services/caregiver_dashboard_service.dart';

class LivePatientOverviewScreen extends StatefulWidget {
  final String patientId;
  final String? patientName;

  const LivePatientOverviewScreen({
    super.key,
    required this.patientId,
    this.patientName,
  });

  @override
  State<LivePatientOverviewScreen> createState() =>
      _LivePatientOverviewScreenState();
}

class _LivePatientOverviewScreenState
    extends State<LivePatientOverviewScreen> {
  CaregiverDashboardSnapshot? _snapshot;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final data =
          await CaregiverDashboardService.instance.loadPatient(
        widget.patientId,
      );

      if (!mounted) return;

      setState(() {
        _snapshot = data;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final snapshot = _snapshot;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.patientName ?? 'Patient Overview'),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? _ErrorView(
                    message: _error!,
                    onRetry: _load,
                  )
                : snapshot == null
                    ? const Center(
                        child: Text(
                          'No patient data available.',
                          style: TextStyle(fontSize: 20),
                        ),
                      )
                    : RefreshIndicator(
                        onRefresh: _load,
                        child: ListView(
                          padding: const EdgeInsets.all(20),
                          children: [
                            _PatientCard(snapshot: snapshot),
                            const SizedBox(height: 16),
                            _RudasCard(snapshot: snapshot),
                            const SizedBox(height: 16),
                            _GamesCard(snapshot: snapshot),
                            const SizedBox(height: 16),
                            _ActivityCard(snapshot: snapshot),
                            const SizedBox(height: 16),
                            _MemoryCard(snapshot: snapshot),
                            const SizedBox(height: 24),
                            const Card(
                              child: Padding(
                                padding: EdgeInsets.all(18),
                                child: Text(
                                  'Safety note: SmritiAI records activity '
                                  'and assessment information. Game results '
                                  'should not be treated as a medical diagnosis.',
                                  style: TextStyle(fontSize: 16),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
      ),
    );
  }
}

class _PatientCard extends StatelessWidget {
  final CaregiverDashboardSnapshot snapshot;

  const _PatientCard({required this.snapshot});

  @override
  Widget build(BuildContext context) {
    final patient = snapshot.patient ?? {};

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            const CircleAvatar(
              radius: 34,
              child: Icon(Icons.person, size: 38),
            ),
            const SizedBox(width: 18),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    (patient['name'] ??
                            patient['full_name'] ??
                            'Patient')
                        .toString(),
                    style: const TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    (patient['email'] ?? '').toString(),
                    style: const TextStyle(fontSize: 16),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RudasCard extends StatelessWidget {
  final CaregiverDashboardSnapshot snapshot;

  const _RudasCard({required this.snapshot});

  @override
  Widget build(BuildContext context) {
    final latest = snapshot.latestRudas;

    final total = latest?['total'];

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'RUDAS',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 14),
            if (latest == null)
              const Text(
                'Baseline assessment is pending.',
                style: TextStyle(fontSize: 18),
              )
            else
              Text(
                'Latest score: ${total ?? '—'} / 30',
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w600,
                ),
              ),
            const SizedBox(height: 12),
            Text(
              'Completed game sessions: ${snapshot.completedGameSessions}',
              style: const TextStyle(fontSize: 17),
            ),
            if (snapshot.rudasDue) ...[
              const SizedBox(height: 12),
              const Text(
                'RUDAS reassessment checkpoint is due.',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _GamesCard extends StatelessWidget {
  final CaregiverDashboardSnapshot snapshot;

  const _GamesCard({required this.snapshot});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Cognitive Games',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Sessions: ${snapshot.games.length}',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 6),
            Text(
              'Average accuracy: ${snapshot.averageAccuracy.toStringAsFixed(1)}%',
              style: const TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActivityCard extends StatelessWidget {
  final CaregiverDashboardSnapshot snapshot;

  const _ActivityCard({required this.snapshot});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Daily Activity',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 14),
            _Row(
              icon: Icons.task_alt,
              label: 'Tasks',
              value: snapshot.tasks.length.toString(),
            ),
            _Row(
              icon: Icons.alarm,
              label: 'Reminders',
              value: snapshot.reminders.length.toString(),
            ),
            _Row(
              icon: Icons.mood,
              label: 'Mood entries',
              value: snapshot.mood.length.toString(),
            ),
          ],
        ),
      ),
    );
  }
}

class _MemoryCard extends StatelessWidget {
  final CaregiverDashboardSnapshot snapshot;

  const _MemoryCard({required this.snapshot});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: _Row(
          icon: Icons.photo_album_outlined,
          label: 'Memory stories',
          value: snapshot.stories.length.toString(),
        ),
      ),
    );
  }
}

class _Row extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _Row({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        children: [
          Icon(icon, size: 28),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(fontSize: 18),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;

  const _ErrorView({
    required this.message,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.cloud_off, size: 64),
            const SizedBox(height: 18),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: onRetry,
              child: const Text(
                'Try Again',
                style: TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
