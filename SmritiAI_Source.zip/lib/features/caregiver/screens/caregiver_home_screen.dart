
import 'package:flutter/material.dart';

import '../../../core/auth/user_context.dart';
import '../../../widgets/smriti_ui.dart';

class CaregiverHomeScreen extends StatelessWidget {
  const CaregiverHomeScreen({
    super.key,
  });

  String get patientId =>
      UserContext.patientIdForCaregiver ??
      'p1';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Caregiver Dashboard',
        ),
        actions: [
          IconButton(
            tooltip: 'Settings',
            icon: const Icon(
              Icons.settings_outlined,
            ),
            onPressed: () {
              Navigator.pushNamed(
                context,
                '/language-voice',
              );
            },
          ),
        ],
      ),
      body: ListView(
        padding:
            const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding:
                  const EdgeInsets.all(18),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 30,
                    child: const Icon(
                      Icons.person,
                      size: 32,
                    ),
                  ),
                  const SizedBox(width: 15),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Connected Patient',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight:
                                FontWeight.w700,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Manage care activities safely',
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 12),

          SmritiSectionTitle(
            title: 'Daily Care',
            subtitle:
                'Tasks and reminders',
          ),

          SmritiPatientCard(
            icon: Icons.add_task,
            title: 'Assign a Task',
            subtitle:
                'Give the patient a simple activity',
            onTap: () {
              Navigator.pushNamed(
                context,
                '/caregiver/assign-task',
              );
            },
          ),

          SmritiPatientCard(
            icon: Icons.task_alt,
            title: 'Manage Tasks',
            onTap: () {
              Navigator.pushNamed(
                context,
                '/caregiver/tasks',
              );
            },
          ),

          SmritiPatientCard(
            icon: Icons.notifications_active,
            title: 'Reminders',
            onTap: () {
              Navigator.pushNamed(
                context,
                '/caregiver/reminders',
              );
            },
          ),

          SmritiSectionTitle(
            title: 'Patient Progress',
            subtitle:
                'Activities and assessments',
          ),

          SmritiPatientCard(
            icon: Icons.extension,
            title: 'Game Performance',
            subtitle:
                'Sessions, accuracy and history',
            onTap: () {
              Navigator.pushNamed(
                context,
                '/caregiver/game-progress',
              );
            },
          ),

          SmritiPatientCard(
            icon: Icons.assessment_outlined,
            title: 'RUDAS',
            subtitle:
                'Assessment history and 7-session checkpoint',
            onTap: () {
              Navigator.pushNamed(
                context,
                '/caregiver/rudas-checkpoint',
              );
            },
          ),

          SmritiPatientCard(
            icon: Icons.favorite_outline,
            title: 'Mood',
            subtitle:
                'View recorded mood check-ins',
            onTap: () {
              Navigator.pushNamed(
                context,
                '/caregiver/mood',
              );
            },
          ),

          SmritiSectionTitle(
            title: 'Memories',
            subtitle:
                'Keep meaningful information together',
          ),

          SmritiPatientCard(
            icon: Icons.photo_album_outlined,
            title: 'Memory Manager',
            subtitle:
                'Stories, photos and familiar people',
            onTap: () {
              Navigator.pushNamed(
                context,
                '/caregiver/memories',
              );
            },
          ),

          const SizedBox(height: 10),

          Card(
            child: Padding(
              padding:
                  const EdgeInsets.all(18),
              child: Row(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  const Icon(
                    Icons.info_outline,
                    size: 28,
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text(
                      'Game performance is for activity tracking. RUDAS is a separate assessment and should be administered according to the appropriate clinical process.',
                      style: TextStyle(
                        fontSize: 16,
                        height: 1.35,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Phase 34: caregiver connection route: /caregiver/connect-patient
