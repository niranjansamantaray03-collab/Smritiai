import 'package:flutter/material.dart';
import '../../../core/auth/user_context.dart';

import '../../rudas/models/rudas_assessment.dart';
import '../../rudas/screens/rudas_assessment_screen.dart';
import '../../rudas/screens/rudas_history_screen.dart';
import '../../rudas/screens/rudas_trends_screen.dart';
import '../../tasks/screens/caregiver_tasks_screen.dart';
import '../../memory/screens/caregiver_memory_screen.dart';
import '../services/caregiver_service.dart';

class CaregiverPatientScreen extends StatefulWidget {
  final String patientId;

  const CaregiverPatientScreen({
    super.key,
    required this.patientId,
  });

  @override
  State<CaregiverPatientScreen> createState() =>
      _CaregiverPatientScreenState();
}

class _CaregiverPatientScreenState extends State<CaregiverPatientScreen> {
  final CaregiverService _service = CaregiverService.instance;

  @override
  Widget build(BuildContext context) {
    final patient = _service.getPatient(widget.patientId);

    if (patient == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Patient')),
        body: const Center(
          child: Text(
            'Patient not found.',
            style: TextStyle(fontSize: 20),
          ),
        ),
      );
    }

    final summary = _service.getPatientRudasSummary(widget.patientId);
    final baseline = summary['baseline'] as RudasAssessment?;
    final latest = summary['latest'] as RudasAssessment?;
    final assessments =
        (summary['assessments'] as List<RudasAssessment>);
    final sessions = summary['gameSessions'] as int;
    final due = summary['reassessmentDue'] as bool;
    final remaining = summary['sessionsUntilNext'] as int;

    return Scaffold(
      appBar: AppBar(
        title: Text(patient.name),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  const CircleAvatar(
                    radius: 34,
                    child: Icon(Icons.person, size: 38),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          patient.name,
                          style: const TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Patient ID: ${patient.id}',
                          style: const TextStyle(fontSize: 15),
                        ),
                        Text(
                          patient.email,
                          style: const TextStyle(fontSize: 15),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),

          _sectionTitle('🧠 RUDAS'),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (latest == null || latest.notes == 'BASELINE')
                    const Text(
                      'Baseline RUDAS has not been completed.',
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  else ...[
                    const Text(
                      'Latest RUDAS Score',
                      style: TextStyle(fontSize: 18),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      '${latest.total} / 30',
                      style: const TextStyle(
                        fontSize: 34,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      'Recorded ${latest.date.day}/'
                      '${latest.date.month}/${latest.date.year}',
                      style: const TextStyle(fontSize: 16),
                    ),
                  ],

                  const Divider(height: 28),

                  if (baseline != null &&
                      baseline.notes != 'BASELINE')
                    _domainGrid(baseline),

                  if (due) ...[
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(),
                      ),
                      child: const Text(
                        '🔔 RUDAS reassessment is due after 7 completed '
                        'cognitive-game sessions.',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),

          SizedBox(
            height: 62,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.assignment, size: 28),
              label: const Text(
                'Manage Patient Tasks',
                style: TextStyle(fontSize: 18),
              ),
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => CaregiverTasksScreen(
                      patientId: widget.patientId,
                      caregiverId: 'current_caregiver',
                      patientName: patient.name,
                    ),
                  ),
                );
                setState(() {});
              },
            ),
          ),

          const SizedBox(height: 16),

          SizedBox(
            height: 62,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.photo_library, size: 28),
              label: const Text(
                'Manage Memories & Photos',
                style: TextStyle(fontSize: 18),
              ),
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => CaregiverMemoryScreen(
                      patientId: widget.patientId,
                      patientName: patient.name,
                    ),
                  ),
                );
                setState(() {});
              },
            ),
          ),

          const SizedBox(height: 16),

          _sectionTitle('🎮 7-Session Checkpoint'),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text(
                    '$sessions completed sessions',
                    style: const TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  LinearProgressIndicator(
                    value: ((sessions % 7) / 7).clamp(0.0, 1.0),
                    minHeight: 12,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    due
                        ? 'Assessment checkpoint reached'
                        : '$remaining sessions until next RUDAS checkpoint',
                    style: const TextStyle(fontSize: 17),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),

          _sectionTitle('📋 RUDAS Actions'),

          SizedBox(
            height: 64,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.psychology, size: 28),
              label: Text(
                due ? 'Record Reassessment' : 'Record RUDAS Assessment',
                style: const TextStyle(fontSize: 18),
              ),
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => RudasAssessmentScreen(
                      patientId: widget.patientId,
                    ),
                  ),
                );
                setState(() {});
              },
            ),
          ),

          const SizedBox(height: 12),

          SizedBox(
            height: 60,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.history, size: 27),
              label: Text(
                'View History (${assessments.length})',
                style: const TextStyle(fontSize: 18),
              ),
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => RudasHistoryScreen(
                      patientId: widget.patientId,
                    ),
                  ),
                );
                setState(() {});
              },
            ),
          ),

          const SizedBox(height: 12),

          SizedBox(
            height: 60,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.show_chart, size: 27),
              label: const Text(
                'View RUDAS Trends',
                style: TextStyle(fontSize: 18),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => RudasTrendsScreen(
                      patientId: widget.patientId,
                    ),
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 20),

          const Card(
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Text(
                'RUDAS scores are recorded assessments. Cognitive-game '
                'performance is kept separate and does not automatically '
                'generate a RUDAS score.',
                style: TextStyle(fontSize: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 23,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _domainGrid(RudasAssessment assessment) {
    final domains = <String, String>{
      'Memory': '${assessment.memory}/8',
      'Orientation': '${assessment.orientation}/5',
      'Praxis': '${assessment.praxis}/2',
      'Visuoconstruction': '${assessment.visuoconstruction}/3',
      'Judgment': '${assessment.judgment}/4',
      'Language': '${assessment.language}/8',
    };

    return Column(
      children: domains.entries.map(
        (entry) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  entry.key,
                  style: const TextStyle(fontSize: 17),
                ),
                Text(
                  entry.value,
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          );
        },
      ).toList(),
    );
  }
}


// PHASE 13 CAREGIVER PATIENT ID
// Connected patient data must use UserContext.patientIdForCaregiver.
// Supabase connection records will replace the temporary p1 fallback.
