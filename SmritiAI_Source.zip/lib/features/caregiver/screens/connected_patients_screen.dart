
import 'package:flutter/material.dart';

import '../services/caregiver_dashboard_service.dart';
import 'live_patient_overview_screen.dart';

class ConnectedPatientsScreen extends StatefulWidget {
  const ConnectedPatientsScreen({super.key});

  @override
  State<ConnectedPatientsScreen> createState() =>
      _ConnectedPatientsScreenState();
}

class _ConnectedPatientsScreenState
    extends State<ConnectedPatientsScreen> {
  List<Map<String, dynamic>> _patients = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final patients =
          await CaregiverDashboardService.instance.getConnectedPatients();

      if (!mounted) return;

      setState(() {
        _patients = patients;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Patients'),
        actions: [
          IconButton(
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(
                        _error!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 18),
                      ),
                    ),
                  )
                : _patients.isEmpty
                    ? const Center(
                        child: Padding(
                          padding: EdgeInsets.all(24),
                          child: Text(
                            'No connected patients yet.\n\n'
                            'Use Connect Patient to connect a patient '
                            'using their connection code.',
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 20),
                          ),
                        ),
                      )
                    : RefreshIndicator(
                        onRefresh: _load,
                        child: ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: _patients.length,
                          itemBuilder: (context, index) {
                            final patient = _patients[index];

                            final id =
                                (patient['id'] ??
                                        patient['patient_id'] ??
                                        '')
                                    .toString();

                            final name =
                                (patient['name'] ??
                                        patient['full_name'] ??
                                        'Patient')
                                    .toString();

                            final email =
                                (patient['email'] ?? '').toString();

                            return Card(
                              child: ListTile(
                                contentPadding:
                                    const EdgeInsets.all(16),
                                leading: const CircleAvatar(
                                  radius: 28,
                                  child: Icon(Icons.person),
                                ),
                                title: Text(
                                  name,
                                  style: const TextStyle(
                                    fontSize: 21,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                subtitle: Text(
                                  email,
                                  style: const TextStyle(fontSize: 16),
                                ),
                                trailing: const Icon(
                                  Icons.arrow_forward_ios,
                                ),
                                onTap: id.isEmpty
                                    ? null
                                    : () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (_) =>
                                                LivePatientOverviewScreen(
                                              patientId: id,
                                              patientName: name,
                                            ),
                                          ),
                                        );
                                      },
                              ),
                            );
                          },
                        ),
                      ),
      ),
    );
  }
}
