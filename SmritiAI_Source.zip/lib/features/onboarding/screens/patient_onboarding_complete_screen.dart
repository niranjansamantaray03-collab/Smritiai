
import 'package:flutter/material.dart';

import '../../../core/theme/smriti_theme.dart';

class PatientOnboardingCompleteScreen extends StatelessWidget {
  final String patientName;

  const PatientOnboardingCompleteScreen({
    super.key,
    required this.patientName,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SmritiAI'),
        automaticallyImplyLeading: false,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.check_circle_outline,
                size: 90,
              ),
              const SizedBox(height: 24),
              Text(
                'Welcome, $patientName',
                textAlign: TextAlign.center,
                style: SmritiTheme.largeTitle,
              ),
              const SizedBox(height: 16),
              const Text(
                'Your SmritiAI patient profile has been created.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 20),
              ),
              const SizedBox(height: 12),
              const Text(
                'Your RUDAS baseline record has also been created. '
                'A caregiver or authorised assessor can complete the baseline assessment.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                height: 64,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamedAndRemoveUntil(
                      context,
                      '/patient',
                      (_) => false,
                    );
                  },
                  child: const Text(
                    'Continue to My App',
                    style: TextStyle(fontSize: 20),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
