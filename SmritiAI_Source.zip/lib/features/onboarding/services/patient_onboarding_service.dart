
import '../../rudas/services/rudas_registration_service.dart';

class PatientOnboardingService {
  PatientOnboardingService._();

  static final PatientOnboardingService instance =
      PatientOnboardingService._();

  Future<void> initializeForPatient({
    required String patientId,
    required String patientName,
    required String language,
  }) async {
    if (patientId.trim().isEmpty) {
      throw StateError('Patient ID is required.');
    }

    // Idempotent: this creates the patient's baseline only if one
    // does not already exist.
    await RudasRegistrationService.instance.ensureBaseline(
      patientId: patientId,
    );
  }
}
