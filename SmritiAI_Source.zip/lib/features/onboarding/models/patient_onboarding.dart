
class PatientOnboarding {
  final String patientId;
  final String name;
  final String email;
  final String language;
  final DateTime registeredAt;
  final bool rudasBaselineCreated;

  const PatientOnboarding({
    required this.patientId,
    required this.name,
    required this.email,
    required this.language,
    required this.registeredAt,
    required this.rudasBaselineCreated,
  });

  Map<String, dynamic> toMap() => {
        'patient_id': patientId,
        'name': name,
        'email': email,
        'language': language,
        'registered_at': registeredAt.toIso8601String(),
        'rudas_baseline_created': rudasBaselineCreated,
      };
}
