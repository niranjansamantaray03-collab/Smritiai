
import 'package:flutter/material.dart';

class IntegrationStatusScreen extends StatelessWidget {
  const IntegrationStatusScreen({
    super.key,
  });

  static const items = [
    ('Authentication', Icons.lock_outline),
    ('Patient / caregiver roles', Icons.people_outline),
    ('Patient connections', Icons.link),
    ('Tasks', Icons.task_alt),
    ('Reminders', Icons.notifications_outlined),
    ('Cognitive games', Icons.extension_outlined),
    ('RUDAS', Icons.psychology_outlined),
    ('First-time hand assessment', Icons.pan_tool_outlined),
    ('Memory stories', Icons.menu_book_outlined),
    ('Memory photos', Icons.photo_library_outlined),
    ('Mood check-in', Icons.mood_outlined),
    ('Voice / speech', Icons.mic_none),
    ('Offline storage', Icons.offline_bolt_outlined),
    ('Cloud sync', Icons.cloud_sync_outlined),
    ('Private storage', Icons.cloud_outlined),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'SmritiAI Integration',
        ),
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(18),
        itemCount: items.length,
        separatorBuilder: (_, __) =>
            const SizedBox(height: 8),
        itemBuilder: (_, index) {
          final item = items[index];

          return Card(
            child: ListTile(
              leading: Icon(
                item.$2,
                size: 30,
              ),
              title: Text(
                item.$1,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              trailing: const Icon(
                Icons.check_circle_outline,
              ),
            ),
          );
        },
      ),
    );
  }
}
