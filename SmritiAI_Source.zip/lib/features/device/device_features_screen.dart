
import 'package:flutter/material.dart';

import '../memory/services/native_memory_media_controller.dart';
import '../patient/welcome_music_controller.dart';
import '../voice/services/native_voice_controller.dart';
import '../voice/voice_locale.dart';
import '../notifications/native_notification_controller.dart';

class DeviceFeaturesScreen extends StatefulWidget {
  const DeviceFeaturesScreen({super.key});

  @override
  State<DeviceFeaturesScreen> createState() =>
      _DeviceFeaturesScreenState();
}

class _DeviceFeaturesScreenState
    extends State<DeviceFeaturesScreen> {

  String status = 'Ready';

  Future<void> _testVoice() async {
    setState(() => status = 'Speaking...');

    await NativeVoiceController.instance.speak(
      'Welcome to SmritiAI. You are doing well.',
      locale: VoiceLocale.english,
    );

    if (!mounted) return;

    setState(() => status = 'Voice test complete');
  }

  Future<void> _testMusic() async {
    await WelcomeMusicController.instance.play();

    if (!mounted) return;

    setState(() => status = 'Welcome music started');
  }

  Future<void> _testNotification() async {
    await NativeNotificationController.instance.requestPermission();

    await NativeNotificationController.instance.showNow(
      id: 9001,
      title: 'SmritiAI',
      body: 'This is a test reminder.',
    );

    if (!mounted) return;

    setState(() => status = 'Test notification requested');
  }

  Future<void> _testPhoto() async {
    final file =
        await NativeMemoryMediaController.instance.selectPhoto();

    if (!mounted) return;

    setState(() {
      status = file == null
          ? 'No photo selected'
          : 'Photo selected: ${file.path.split('/').last}';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Device Features'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Text(
                status,
                style: const TextStyle(fontSize: 18),
              ),
            ),
          ),
          const SizedBox(height: 15),

          FilledButton.icon(
            onPressed: _testVoice,
            icon: const Icon(Icons.volume_up),
            label: const Padding(
              padding: EdgeInsets.all(14),
              child: Text(
                'Test Voice',
                style: TextStyle(fontSize: 18),
              ),
            ),
          ),

          const SizedBox(height: 12),

          FilledButton.icon(
            onPressed: _testMusic,
            icon: const Icon(Icons.music_note),
            label: const Padding(
              padding: EdgeInsets.all(14),
              child: Text(
                'Test Welcome Music',
                style: TextStyle(fontSize: 18),
              ),
            ),
          ),

          const SizedBox(height: 12),

          FilledButton.icon(
            onPressed: _testPhoto,
            icon: const Icon(Icons.photo_library),
            label: const Padding(
              padding: EdgeInsets.all(14),
              child: Text(
                'Choose Memory Photo',
                style: TextStyle(fontSize: 18),
              ),
            ),
          ),

          const SizedBox(height: 12),

          FilledButton.icon(
            onPressed: _testNotification,
            icon: const Icon(Icons.notifications),
            label: const Padding(
              padding: EdgeInsets.all(14),
              child: Text(
                'Test Notification',
                style: TextStyle(fontSize: 18),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
