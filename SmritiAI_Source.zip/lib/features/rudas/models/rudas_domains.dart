class RudasDomains {
  static const memory = 'Memory';
  static const orientation = 'Orientation';
  static const praxis = 'Praxis';
  static const visuoconstruction = 'Visuoconstruction';
  static const judgment = 'Judgment';
  static const language = 'Language';

  static const all = [
    memory,
    orientation,
    praxis,
    visuoconstruction,
    judgment,
    language,
  ];

  static const maximums = {
    memory: 8,
    orientation: 5,
    praxis: 2,
    visuoconstruction: 3,
    judgment: 4,
    language: 8,
  };
}
