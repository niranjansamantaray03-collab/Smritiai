import 'package:flutter/material.dart';

import '../services/rudas_service.dart';

class RudasAssessmentScreen extends StatefulWidget {
  final String patientId;

  const RudasAssessmentScreen({
    super.key,
    required this.patientId,
  });

  @override
  State<RudasAssessmentScreen> createState() => _RudasAssessmentScreenState();
}

class _RudasAssessmentScreenState extends State<RudasAssessmentScreen> {
  final RudasService _service = RudasService.instance;

  final Map<String, int> _scores = {
    'Memory': 0,
    'Orientation': 0,
    'Praxis': 0,
    'Visuoconstruction': 0,
    'Judgment': 0,
    'Language': 0,
  };

  final Map<String, int> _maximums = {
    'Memory': 8,
    'Orientation': 5,
    'Praxis': 2,
    'Visuoconstruction': 3,
    'Judgment': 4,
    'Language': 8,
  };

  final TextEditingController _notesController = TextEditingController();

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  int get total {
    return _scores.values.fold(0, (sum, value) => sum + value);
  }

  void _save() {
    final baseline = _service.getBaseline(widget.patientId);

    if (baseline == null || baseline.notes == 'BASELINE') {
      _service.completeBaseline(
        patientId: widget.patientId,
        memory: _scores['Memory']!,
        orientation: _scores['Orientation']!,
        praxis: _scores['Praxis']!,
        visuoconstruction: _scores['Visuoconstruction']!,
        judgment: _scores['Judgment']!,
        language: _scores['Language']!,
        notes: _notesController.text,
      );
    } else {
      _service.addAssessment(
        _createReassessment(),
      );
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('RUDAS assessment recorded successfully.'),
      ),
    );

    Navigator.pop(context);
  }

  dynamic _createReassessment() {
    return _serviceAssessment();
  }

  dynamic _serviceAssessment() {
    return _buildAssessment();
  }

  dynamic _buildAssessment() {
    // Kept in one place so the model remains independent of the UI.
    // ignore: avoid_dynamic_calls
    return _assessmentObject();
  }

  dynamic _assessmentObject() {
    // The import is intentionally local through the service model.
    return _makeAssessment();
  }

  dynamic _makeAssessment() {
    // This method is replaced below by the strongly typed helper.
    return _typedAssessment();
  }

  dynamic _typedAssessment() {
    // ignore: avoid_dynamic_calls
    return _createTypedAssessment();
  }

  dynamic _createTypedAssessment() {
    // ignore: avoid_dynamic_calls
    return RudasAssessmentFactory.create(
      patientId: widget.patientId,
      memory: _scores['Memory']!,
      orientation: _scores['Orientation']!,
      praxis: _scores['Praxis']!,
      visuoconstruction: _scores['Visuoconstruction']!,
      judgment: _scores['Judgment']!,
      language: _scores['Language']!,
      notes: _notesController.text,
    );
  }

  @override
  Widget build(BuildContext context) {
    final baseline = _service.getBaseline(widget.patientId);
    final title = baseline == null || baseline.notes == 'BASELINE'
        ? 'Baseline RUDAS'
        : 'RUDAS Reassessment';

    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Text(
                'Total: $total / 30',
                style: const TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),

          ..._maximums.entries.map(
            (entry) => _scoreCard(
              domain: entry.key,
              maximum: entry.value,
            ),
          ),

          const SizedBox(height: 8),

          TextField(
            controller: _notesController,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'Assessor notes',
              border: OutlineInputBorder(),
              alignLabelWithHint: true,
            ),
          ),

          const SizedBox(height: 20),

          SizedBox(
            height: 68,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.save, size: 28),
              label: const Text(
                'Save Assessment',
                style: TextStyle(fontSize: 20),
              ),
              onPressed: _save,
            ),
          ),
        ],
      ),
    );
  }

  Widget _scoreCard({
    required String domain,
    required int maximum,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '$domain  •  ${_scores[domain]} / $maximum',
              style: const TextStyle(
                fontSize: 21,
                fontWeight: FontWeight.bold,
              ),
            ),
            Slider(
              value: _scores[domain]!.toDouble(),
              min: 0,
              max: maximum.toDouble(),
              divisions: maximum,
              label: '${_scores[domain]}',
              onChanged: (value) {
                setState(() {
                  _scores[domain] = value.round();
                });
              },
            ),
          ],
        ),
      ),
    );
  }
}

/// Keeps RUDAS model creation in one place.
class RudasAssessmentFactory {
  static dynamic create({
    required String patientId,
    required int memory,
    required int orientation,
    required int praxis,
    required int visuoconstruction,
    required int judgment,
    required int language,
    required String notes,
  }) {
    return RudasAssessment(
      id: 'rudas_${patientId}_${DateTime.now().millisecondsSinceEpoch}',
      patientId: patientId,
      date: DateTime.now(),
      memory: memory,
      orientation: orientation,
      praxis: praxis,
      visuoconstruction: visuoconstruction,
      judgment: judgment,
      language: language,
      total: memory +
          orientation +
          praxis +
          visuoconstruction +
          judgment +
          language,
      notes: 'REASSESSMENT_COMPLETED${notes.isEmpty ? '' : ' | $notes'}',
    );
  }
}
