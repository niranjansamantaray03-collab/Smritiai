import 'package:flutter/material.dart';

import '../services/rudas_service.dart';

class RudasTrendsScreen extends StatelessWidget {
  final String patientId;

  const RudasTrendsScreen({
    super.key,
    required this.patientId,
  });

  @override
  Widget build(BuildContext context) {
    final assessments =
        RudasService.instance.getAssessments(patientId).toList()
          ..sort((a, b) => a.date.compareTo(b.date));

    return Scaffold(
      appBar: AppBar(
        title: const Text('RUDAS Trends'),
      ),
      body: assessments.isEmpty
          ? const Center(
              child: Text(
                'RUDAS trend data will appear after assessments are recorded.',
                style: TextStyle(fontSize: 20),
                textAlign: TextAlign.center,
              ),
            )
          : ListView(
              padding: const EdgeInsets.all(18),
              children: [
                const Card(
                  child: Padding(
                    padding: EdgeInsets.all(18),
                    child: Text(
                      'Assessment progress',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                ...assessments.asMap().entries.map(
                  (entry) {
                    final index = entry.key;
                    final assessment = entry.value;

                    return Card(
                      child: ListTile(
                        leading: CircleAvatar(
                          child: Text('${index + 1}'),
                        ),
                        title: Text(
                          index == 0
                              ? 'Baseline'
                              : 'Assessment ${index + 1}',
                          style: const TextStyle(fontSize: 19),
                        ),
                        subtitle: Text(
                          '${assessment.date.day}/'
                          '${assessment.date.month}/'
                          '${assessment.date.year}',
                        ),
                        trailing: Text(
                          '${assessment.total}/30',
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 16),
                const Card(
                  child: Padding(
                    padding: EdgeInsets.all(18),
                    child: Text(
                      'These records show assessment history only. '
                      'They are not a diagnosis and should be interpreted '
                      'by an appropriately qualified professional.',
                      style: TextStyle(fontSize: 17),
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
