import 'package:flutter/material.dart';

import '../services/rudas_service.dart';

class RudasHistoryScreen extends StatelessWidget {
  final String patientId;

  const RudasHistoryScreen({
    super.key,
    required this.patientId,
  });

  @override
  Widget build(BuildContext context) {
    final assessments =
        RudasService.instance.getAssessments(patientId).toList()
          ..sort((a, b) => b.date.compareTo(a.date));

    return Scaffold(
      appBar: AppBar(
        title: const Text('RUDAS History'),
      ),
      body: assessments.isEmpty
          ? const Center(
              child: Text(
                'No RUDAS assessments recorded yet.',
                style: TextStyle(fontSize: 20),
                textAlign: TextAlign.center,
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: assessments.length,
              itemBuilder: (context, index) {
                final assessment = assessments[index];

                final isBaseline =
                    assessment.notes?.contains('BASELINE') ?? false;

                return Card(
                  margin: const EdgeInsets.only(bottom: 14),
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isBaseline
                              ? 'Baseline Assessment'
                              : 'RUDAS Reassessment',
                          style: const TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          '${assessment.date.day.toString().padLeft(2, '0')}/'
                          '${assessment.date.month.toString().padLeft(2, '0')}/'
                          '${assessment.date.year}',
                          style: const TextStyle(fontSize: 17),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          'Total: ${assessment.total} / 30',
                          style: const TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Divider(height: 24),
                        _domain(
                          'Memory',
                          assessment.memory,
                          8,
                        ),
                        _domain(
                          'Orientation',
                          assessment.orientation,
                          5,
                        ),
                        _domain(
                          'Praxis',
                          assessment.praxis,
                          2,
                        ),
                        _domain(
                          'Visuoconstruction',
                          assessment.visuoconstruction,
                          3,
                        ),
                        _domain(
                          'Judgment',
                          assessment.judgment,
                          4,
                        ),
                        _domain(
                          'Language',
                          assessment.language,
                          8,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  Widget _domain(String name, int score, int max) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            name,
            style: const TextStyle(fontSize: 17),
          ),
          Text(
            '$score / $max',
            style: const TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
