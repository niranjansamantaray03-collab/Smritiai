
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../models/rudas_hand_jumble.dart';

class RudasHandJumbleScreen extends StatefulWidget {
  final String? patientId;
  final bool firstAssessment;
  final String patientId;

  const RudasHandJumbleScreen({
    super.key,
    this.patientId,
    this.firstAssessment = false,
    required this.patientId,
  });

  @override
  State<RudasHandJumbleScreen> createState() =>
      _RudasHandJumbleScreenState();
}

class _RudasHandJumbleScreenState
    extends State<RudasHandJumbleScreen> {

  CameraController? _controller;
  List<CameraDescription> _cameras = [];

  bool cameraReady = false;
  bool cameraUsed = false;

  int step = 0;
  bool completed = false;

  bool leftHandShown = false;
  bool rightHandShown = false;
  bool leftToRightShoulder = false;
  bool rightToLeftShoulder = false;

  bool fistPalmAlternation = false;
  bool reverseSequence = false;

  int praxisScore = 0;
  int orientationScore = 0;

  final TextEditingController notesController =
      TextEditingController();

  final List<_RudasStep> steps = const [
    _RudasStep(
      title: 'Show your LEFT hand',
      instruction:
          'Please show your left hand to the assessor.',
      icon: Icons.pan_tool_outlined,
      type: 'left',
    ),
    _RudasStep(
      title: 'Show your RIGHT hand',
      instruction:
          'Now please show your right hand.',
      icon: Icons.pan_tool_outlined,
      type: 'right',
    ),
    _RudasStep(
      title: 'Left hand → right shoulder',
      instruction:
          'With your left hand, touch your right shoulder.',
      icon: Icons.accessibility_new,
      type: 'left_right_shoulder',
    ),
    _RudasStep(
      title: 'Right hand → left shoulder',
      instruction:
          'With your right hand, touch your left shoulder.',
      icon: Icons.accessibility_new,
      type: 'right_left_shoulder',
    ),
    _RudasStep(
      title: 'Fist → palm → fist → palm',
      instruction:
          'Watch the assessor and copy the alternating hand movement.',
      icon: Icons.back_hand_outlined,
      type: 'fist_palm',
    ),
    _RudasStep(
      title: 'Reverse the movement',
      instruction:
          'Now copy the movement in the reverse order.',
      icon: Icons.sync,
      type: 'reverse',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _prepareCamera();
  }

  Future<void> _prepareCamera() async {
    try {
      _cameras = await availableCameras();

      if (_cameras.isEmpty) return;

      final camera = _cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.front,
        orElse: () => _cameras.first,
      );

      _controller = CameraController(
        camera,
        ResolutionPreset.medium,
        enableAudio: false,
      );

      await _controller!.initialize();

      if (!mounted) return;

      setState(() {
        cameraReady = true;
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        cameraReady = false;
      });
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    notesController.dispose();
    super.dispose();
  }

  void _markStepComplete() {
    final type = steps[step].type;

    setState(() {
      cameraUsed = cameraReady;

      switch (type) {
        case 'left':
          leftHandShown = true;
          orientationScore++;
          break;

        case 'right':
          rightHandShown = true;
          orientationScore++;
          break;

        case 'left_right_shoulder':
          leftToRightShoulder = true;
          orientationScore++;
          break;

        case 'right_left_shoulder':
          rightToLeftShoulder = true;
          orientationScore++;
          break;

        case 'fist_palm':
          fistPalmAlternation = true;
          praxisScore = praxisScore < 1 ? 1 : praxisScore;
          break;

        case 'reverse':
          reverseSequence = true;
          praxisScore = 2;
          break;
      }

      if (step == steps.length - 1) {
        completed = true;
      } else {
        step++;
      }
    });
  }

  Future<void> _takeReferencePhoto() async {
    if (_controller == null ||
        !_controller!.value.isInitialized) {
      return;
    }

    try {
      await _controller!.takePicture();

      if (!mounted) return;

      setState(() {
        cameraUsed = true;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Reference captured for the assessor.',
          ),
        ),
      );
    } catch (_) {}
  }

  RudasHandJumble _buildResult() {
    return RudasHandJumble(
      id: const Uuid().v4(),
      patientId: widget.patientId,
      performedAt: DateTime.now(),
      cameraUsed: cameraUsed,
      leftHandShown: leftHandShown,
      rightHandShown: rightHandShown,
      leftToRightShoulder: leftToRightShoulder,
      rightToLeftShoulder: rightToLeftShoulder,
      fistPalmAlternation: fistPalmAlternation,
      reverseSequence: reverseSequence,
      praxisScore: praxisScore,
      orientationScore: orientationScore,
      assessorNotes: notesController.text.trim(),
    );
  }

  Widget _cameraPreview() {
    if (!cameraReady ||
        _controller == null ||
        !_controller!.value.isInitialized) {
      return Container(
        height: 230,
        decoration: BoxDecoration(
          color: Colors.black12,
          borderRadius: BorderRadius.circular(20),
        ),
        child: const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.videocam_off_outlined,
                size: 48,
              ),
              SizedBox(height: 10),
              Text(
                'Camera unavailable',
                style: TextStyle(fontSize: 17),
              ),
            ],
          ),
        ),
      );
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: SizedBox(
        height: 260,
        width: double.infinity,
        child: CameraPreview(_controller!),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (completed) {
      final result = _buildResult();

      return Scaffold(
        appBar: AppBar(
          title: const Text('RUDAS Hand Assessment'),
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const Icon(
                Icons.check_circle_outline,
                size: 80,
              ),
              const SizedBox(height: 12),
              const Text(
                'Hand assessment completed',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 27,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 24),

              Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Observed movement',
                        style: TextStyle(
                          fontSize: 21,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 15),
                      Text(
                        'Orientation observations: '
                        '$orientationScore',
                        style: const TextStyle(fontSize: 18),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Praxis observation: '
                        '$praxisScore / 2',
                        style: const TextStyle(fontSize: 18),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'The assessor should enter the official '
                        'RUDAS score according to the standardized '
                        'RUDAS instructions.',
                        style: TextStyle(fontSize: 15),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 20),

              TextField(
                controller: notesController,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'Assessor notes',
                  hintText:
                      'Describe any difficulty observed...',
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 20),

              FilledButton.icon(
                onPressed: () {
                  Navigator.pop(context, result);
                },
                icon: const Icon(Icons.check),
                label: const Padding(
                  padding: EdgeInsets.all(14),
                  child: Text(
                    'Return to RUDAS Assessment',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    final current = steps[step];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'RUDAS Hand Assessment ${step + 1}/${steps.length}',
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            LinearProgressIndicator(
              value: (step + 1) / steps.length,
              minHeight: 8,
            ),

            const SizedBox(height: 20),

            Card(
              child: Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  children: [
                    Icon(
                      current.icon,
                      size: 62,
                    ),
                    const SizedBox(height: 15),
                    Text(
                      current.title,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      current.instruction,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 19),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 18),

            _cameraPreview(),

            const SizedBox(height: 12),

            if (cameraReady)
              OutlinedButton.icon(
                onPressed: _takeReferencePhoto,
                icon: const Icon(Icons.camera_alt),
                label: const Padding(
                  padding: EdgeInsets.all(12),
                  child: Text(
                    'Capture reference',
                    style: TextStyle(fontSize: 17),
                  ),
                ),
              ),

            const SizedBox(height: 18),

            const Card(
              child: Padding(
                padding: EdgeInsets.all(15),
                child: Text(
                  'Assessor: demonstrate the movement first when '
                  'required, then observe and mark whether the '
                  'patient follows the instruction.',
                  style: TextStyle(fontSize: 15),
                ),
              ),
            ),

            const SizedBox(height: 18),

            FilledButton(
              onPressed: _markStepComplete,
              child: const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'Observed / Continue',
                  style: TextStyle(fontSize: 20),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RudasStep {
  final String title;
  final String instruction;
  final IconData icon;
  final String type;

  const _RudasStep({
    required this.title,
    required this.instruction,
    required this.icon,
    required this.type,
  });
}
