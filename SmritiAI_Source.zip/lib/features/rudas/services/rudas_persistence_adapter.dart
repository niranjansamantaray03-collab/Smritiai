
import '../../../data/persistence/feature_write_service.dart';
import '../models/rudas_assessment.dart';

class RudasPersistenceAdapter {
  RudasPersistenceAdapter._();

  static final RudasPersistenceAdapter instance =
      RudasPersistenceAdapter._();

  Future<void> save(RudasAssessment assessment) {
    return FeatureWriteService.instance.saveRudas(assessment);
  }
}
