
import 'package:shared_preferences/shared_preferences.dart';

class RudasFirstAssessmentService {
  RudasFirstAssessmentService._();

  static final RudasFirstAssessmentService instance =
      RudasFirstAssessmentService._();

  String _key(String patientId) =>
      'smritiai_rudas_first_hand_jumble_$patientId';

  Future<bool> isFirstAssessment(
    String patientId,
  ) async {
    final prefs =
        await SharedPreferences.getInstance();

    return !(prefs.getBool(_key(patientId)) ?? false);
  }

  Future<void> markHandJumbleCompleted(
    String patientId,
  ) async {
    final prefs =
        await SharedPreferences.getInstance();

    await prefs.setBool(
      _key(patientId),
      true,
    );
  }

  Future<void> resetForTesting(
    String patientId,
  ) async {
    final prefs =
        await SharedPreferences.getInstance();

    await prefs.remove(_key(patientId));
  }
}
