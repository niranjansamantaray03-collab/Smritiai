
import '../models/rudas_assessment.dart';
import '../../../data/persistence/persistence_manager.dart';
import '../../../data/sync/sync_manager.dart';

class RudasService {
  RudasService._();

  static final RudasService instance =
      RudasService._();

  final Map<String, List<RudasAssessment>>
      _assessments = {};

  final Map<String, int>
      _completedGameSessions = {};

  final Set<String> _baselineCreated =
      {};

  bool _loaded = false;

  Future<void> initialize() async {
    if (_loaded) return;

    final records =
        await PersistenceManager.instance
            .getAll('rudas_assessments');

    for (final record in records) {
      try {
        final assessment =
            RudasAssessment.fromMap(
          record,
        );

        _assessments
            .putIfAbsent(
              assessment.patientId,
              () => [],
            )
            .add(assessment);

        _baselineCreated
            .add(assessment.patientId);
      } catch (_) {}
    }

    _loaded = true;
  }

  Future<RudasAssessment>
      ensureBaseline(
    String patientId, {
    String? assessorId,
  }) async {
    await initialize();

    final existing =
        _assessments[patientId] ?? [];

    final baseline =
        existing.where(
      (item) =>
          item.notes == 'BASELINE',
    );

    if (baseline.isNotEmpty) {
      return baseline.first;
    }

    final pending =
        RudasAssessment(
      id:
          'rudas_baseline_$patientId',
      patientId: patientId,
      date: DateTime.now(),
      memory: 0,
      orientation: 0,
      praxis: 0,
      visuoconstruction: 0,
      judgment: 0,
      language: 0,
      total: 0,
      assessorId: assessorId,
      notes: 'BASELINE',
    );

    _assessments
        .putIfAbsent(
          patientId,
          () => [],
        )
        .add(pending);

    _baselineCreated.add(patientId);

    await PersistenceManager.instance
        .save(
      'rudas_assessments',
      pending.id,
      pending.toMap(),
    );

    return pending;
  }

  Future<void> completeBaseline(
    RudasAssessment assessment,
  ) async {
    await initialize();

    final list =
        _assessments[
          assessment.patientId] ??
            [];

    list.removeWhere(
      (item) => item.id == assessment.id,
    );

    list.add(assessment);

    _assessments[
        assessment.patientId] = list;

    await PersistenceManager.instance
        .save(
      'rudas_assessments',
      assessment.id,
      assessment.toMap(),
    );

    SyncManager.instance.queueRecord(
      collection: 'rudas_assessments',
      patientId:
          assessment.patientId,
      operation: 'upsert',
      data: assessment.toMap(),
    );
  }

  Future<void> addAssessment(
    RudasAssessment assessment,
  ) async {
    await initialize();

    final list =
        _assessments
            .putIfAbsent(
              assessment.patientId,
              () => [],
            );

    list.add(assessment);

    await PersistenceManager.instance
        .save(
      'rudas_assessments',
      assessment.id,
      assessment.toMap(),
    );

    SyncManager.instance.queueRecord(
      collection: 'rudas_assessments',
      patientId:
          assessment.patientId,
      operation: 'upsert',
      data: assessment.toMap(),
    );

    _completedGameSessions[
        assessment.patientId] = 0;
  }

  Future<void>
      recordCompletedGameSession(
    String patientId,
  ) async {
    await initialize();

    final current =
        _completedGameSessions[
                patientId] ??
            0;

    _completedGameSessions[
        patientId] = current + 1;

    await PersistenceManager.instance
        .save(
      'rudas_checkpoints',
      patientId,
      {
        'id': patientId,
        'patient_id': patientId,
        'completed_game_sessions':
            current + 1,
        'updated_at':
            DateTime.now()
                .toIso8601String(),
      },
    );
  }

  Future<int> completedGameSessions(
    String patientId,
  ) async {
    await initialize();

    return _completedGameSessions[
            patientId] ??
        0;
  }

  Future<bool> isReassessmentDue(
    String patientId,
  ) async {
    final count =
        await completedGameSessions(
      patientId,
    );

    return count >= 7;
  }

  Future<int> sessionsUntilNextAssessment(
    String patientId,
  ) async {
    final count =
        await completedGameSessions(
      patientId,
    );

    final remainder = count % 7;

    return remainder == 0
        ? 7
        : 7 - remainder;
  }

  Future<List<RudasAssessment>>
      getAssessments(
    String patientId,
  ) async {
    await initialize();

    final result =
        List<RudasAssessment>.from(
      _assessments[patientId] ??
          const [],
    );

    result.sort(
      (a, b) => b.date
          .compareTo(a.date),
    );

    return result;
  }

  Future<RudasAssessment?>
      getBaseline(
    String patientId,
  ) async {
    final all =
        await getAssessments(
      patientId,
    );

    for (final assessment in all) {
      if (assessment.notes ==
          'BASELINE') {
        return assessment;
      }
    }

    return null;
  }

  Future<RudasAssessment?>
      getLatest(
    String patientId,
  ) async {
    final all =
        await getAssessments(
      patientId,
    );

    if (all.isEmpty) return null;

    return all.first;
  }

  Future<void> resetCheckpoint(
    String patientId,
  ) async {
    _completedGameSessions[
        patientId] = 0;

    await PersistenceManager.instance
        .save(
      'rudas_checkpoints',
      patientId,
      {
        'id': patientId,
        'patient_id': patientId,
        'completed_game_sessions': 0,
        'updated_at':
            DateTime.now()
                .toIso8601String(),
      },
    );
  }
}
