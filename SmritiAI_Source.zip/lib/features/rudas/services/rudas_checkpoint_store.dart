
import 'package:shared_preferences/shared_preferences.dart';

class RudasCheckpointStore {
  RudasCheckpointStore._();

  static final RudasCheckpointStore instance = RudasCheckpointStore._();

  String _key(String patientId) => 'smritiai_rudas_completed_sessions_$patientId';

  Future<int> getCompletedSessions(String patientId) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_key(patientId)) ?? 0;
  }

  Future<void> setCompletedSessions(
    String patientId,
    int value,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_key(patientId), value);
  }

  Future<int> increment(String patientId) async {
    final current = await getCompletedSessions(patientId);
    final next = current + 1;
    await setCompletedSessions(patientId, next);
    return next;
  }

  Future<void> reset(String patientId) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key(patientId));
  }
}
