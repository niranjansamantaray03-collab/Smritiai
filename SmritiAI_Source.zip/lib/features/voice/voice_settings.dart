
class VoiceSettings {
  final bool speechEnabled;
  final bool musicEnabled;
  final double speechRate;

  const VoiceSettings({
    this.speechEnabled = true,
    this.musicEnabled = true,
    this.speechRate = 0.42,
  });

  VoiceSettings copyWith({
    bool? speechEnabled,
    bool? musicEnabled,
    double? speechRate,
  }) {
    return VoiceSettings(
      speechEnabled:
          speechEnabled ??
              this.speechEnabled,
      musicEnabled:
          musicEnabled ??
              this.musicEnabled,
      speechRate:
          speechRate ??
              this.speechRate,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'speech_enabled':
          speechEnabled,
      'music_enabled':
          musicEnabled,
      'speech_rate':
          speechRate,
    };
  }
}
