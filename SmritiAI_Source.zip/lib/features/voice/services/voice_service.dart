
import '../voice_locale.dart';

abstract class VoiceAdapter {
  Future<void> initialize();

  Future<void> speak(
    String text, {
    required VoiceLocale locale,
    double rate,
    double pitch,
    double volume,
  });

  Future<void> stop();

  Future<bool> listen({
    required VoiceLocale locale,
    required void Function(String text)
        onResult,
  });

  Future<void> cancelListening();
}

class VoiceService {
  VoiceService._();

  static final VoiceService instance =
      VoiceService._();

  VoiceAdapter? _adapter;

  VoiceLocale _locale =
      VoiceLocale.english;

  bool enabled = true;

  bool get isAvailable =>
      _adapter != null;

  VoiceLocale get locale =>
      _locale;

  void configure(
    VoiceAdapter adapter,
  ) {
    _adapter = adapter;
  }

  Future<void> initialize() async {
    await _adapter?.initialize();
  }

  void setLanguage(
    VoiceLocale locale,
  ) {
    _locale = locale;
  }

  Future<void> speak(
    String text, {
    double rate = 0.42,
    double pitch = 1.0,
    double volume = 1.0,
  }) async {
    if (!enabled) return;

    if (text.trim().isEmpty) return;

    await _adapter?.speak(
      text,
      locale: _locale,
      rate: rate,
      pitch: pitch,
      volume: volume,
    );
  }

  Future<void> stop() async {
    await _adapter?.stop();
  }

  Future<bool> listen({
    void Function(String text)? onResult,
  }) async {
    if (!enabled) return false;

    return await _adapter?.listen(
          locale: _locale,
          onResult:
              onResult ?? (_) {},
        ) ??
        false;
  }

  Future<void> cancelListening() async {
    await _adapter?.cancelListening();
  }
}
