
import 'package:speech_to_text/speech_to_text.dart';

import '../voice_locale.dart';

class NativeSpeechRecognitionService {
  NativeSpeechRecognitionService._();

  static final NativeSpeechRecognitionService instance =
      NativeSpeechRecognitionService._();

  final SpeechToText _speech = SpeechToText();

  bool _initialized = false;

  Future<bool> initialize() async {
    if (_initialized) return true;

    final available = await _speech.initialize();

    _initialized = available;

    return available;
  }

  String localeFor(VoiceLocale locale) {
    switch (locale) {
      case VoiceLocale.english:
        return 'en_IN';
      case VoiceLocale.hindi:
        return 'hi_IN';
      case VoiceLocale.marathi:
        return 'mr_IN';
    }
  }

  Future<String?> listen({
    VoiceLocale locale = VoiceLocale.english,
    Duration duration = const Duration(seconds: 8),
  }) async {
    final available = await initialize();

    if (!available) return null;

    String? result;

    await _speech.listen(
      localeId: localeFor(locale),
      listenFor: duration,
      onResult: (value) {
        if (value.finalResult) {
          result = value.recognizedWords;
        }
      },
    );

    await Future.delayed(duration);

    await stop();

    return result;
  }

  Future<void> stop() async {
    if (_speech.isListening) {
      await _speech.stop();
    }
  }

  Future<void> cancel() async {
    if (_speech.isListening) {
      await _speech.cancel();
    }
  }
}
