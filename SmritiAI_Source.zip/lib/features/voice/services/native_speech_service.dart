import 'package:speech_to_text/speech_to_text.dart';

class NativeSpeechService {
  NativeSpeechService._();

  static final NativeSpeechService instance = NativeSpeechService._();

  final SpeechToText _speech = SpeechToText();
  bool _available = false;

  bool get available => _available;

  Future<bool> initialize() async {
    _available = await _speech.initialize();
    return _available;
  }

  Future<void> listen({
    required void Function(String text, bool isFinal) onResult,
    String localeId = 'en_IN',
  }) async {
    if (!_available) {
      await initialize();
    }

    if (!_available) return;

    await _speech.listen(
      localeId: localeId,
      onResult: (result) {
        onResult(
          result.recognizedWords,
          result.finalResult,
        );
      },
    );
  }

  Future<void> stop() async {
    await _speech.stop();
  }

  Future<void> cancel() async {
    await _speech.cancel();
  }
}
