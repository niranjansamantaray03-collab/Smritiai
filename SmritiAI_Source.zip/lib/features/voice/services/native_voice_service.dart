import 'package:flutter_tts/flutter_tts.dart';

class NativeVoiceService {
  NativeVoiceService._();

  static final NativeVoiceService instance = NativeVoiceService._();

  final FlutterTts _tts = FlutterTts();
  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;

    await _tts.awaitSpeakCompletion(true);
    await _tts.setSpeechRate(0.42);
    await _tts.setPitch(1.0);
    _initialized = true;
  }

  Future<void> speak(
    String text, {
    String locale = 'en-IN',
  }) async {
    if (text.trim().isEmpty) return;

    await initialize();

    try {
      await _tts.setLanguage(locale);
    } catch (_) {
      await _tts.setLanguage('en-IN');
    }

    await _tts.speak(text);
  }

  Future<void> stop() async {
    await _tts.stop();
  }
}
