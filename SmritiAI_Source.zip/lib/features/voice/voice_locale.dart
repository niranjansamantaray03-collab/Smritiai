
class VoiceLocale {
  final String languageCode;
  final String locale;
  final String displayName;

  const VoiceLocale({
    required this.languageCode,
    required this.locale,
    required this.displayName,
  });

  static const english = VoiceLocale(
    languageCode: 'en',
    locale: 'en-IN',
    displayName: 'English',
  );

  static const hindi = VoiceLocale(
    languageCode: 'hi',
    locale: 'hi-IN',
    displayName: 'हिन्दी',
  );

  static const marathi = VoiceLocale(
    languageCode: 'mr',
    locale: 'mr-IN',
    displayName: 'मराठी',
  );

  static const supported = [
    english,
    hindi,
    marathi,
  ];
}
