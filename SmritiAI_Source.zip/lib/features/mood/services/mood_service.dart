
import '../mood_entry.dart';

class MoodService {
  MoodService._();

  static final MoodService instance =
      MoodService._();

  final Map<String, List<MoodEntry>> _entries = {};

  Future<void> addMood(
    MoodEntry entry,
  ) async {
    final list =
        _entries.putIfAbsent(
      entry.patientId,
      () => [],
    );

    list.add(entry);
  }

  List<MoodEntry> getEntries(
    String patientId,
  ) {
    final list =
        _entries[patientId] ?? const [];

    return List.unmodifiable(
      list.reversed,
    );
  }

  MoodEntry? latest(
    String patientId,
  ) {
    final list =
        getEntries(patientId);

    if (list.isEmpty) return null;

    return list.first;
  }

  void clearPatient(String patientId) {
    _entries.remove(patientId);
  }
}
