
import 'package:flutter/material.dart';

import '../../../core/auth/user_context.dart';
import '../mood_options.dart';
import '../mood_entry.dart';
import '../services/mood_service.dart';

class MoodScreen extends StatefulWidget {
  final String? patientId;

  const MoodScreen({
    super.key,
    this.patientId,
  });

  @override
  State<MoodScreen> createState() =>
      _MoodScreenState();
}

class _MoodScreenState extends State<MoodScreen> {

  late String patientId;

  String? selectedMood;

  final noteController =
      TextEditingController();

  @override
  void initState() {
    super.initState();

    patientId =
        widget.patientId ??
        UserContext.patientIdForCurrentUser ??
        'p1';
  }

  @override
  void dispose() {
    noteController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final previous =
        MoodService.instance.latest(patientId);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'How Am I Feeling?',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                children: [
                  const Icon(
                    Icons.favorite_outline,
                    size: 50,
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'How are you feeling today?',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 23,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Choose the feeling that fits you best.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),

          GridView.builder(
            shrinkWrap: true,
            physics:
                const NeverScrollableScrollPhysics(),
            itemCount: MoodOptions.all.length,
            gridDelegate:
                const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.15,
            ),
            itemBuilder: (_, index) {
              final mood =
                  MoodOptions.all[index];

              final selected =
                  selectedMood == mood.id;

              return Card(
                elevation: selected ? 5 : 1,
                child: InkWell(
                  borderRadius:
                      BorderRadius.circular(18),
                  onTap: () {
                    setState(() {
                      selectedMood = mood.id;
                    });
                  },
                  child: Column(
                    mainAxisAlignment:
                        MainAxisAlignment.center,
                    children: [
                      Text(
                        mood.emoji,
                        style: const TextStyle(
                          fontSize: 42,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        mood.label,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),

          const SizedBox(height: 18),

          TextField(
            controller: noteController,
            minLines: 2,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'Anything you want to say?',
              hintText:
                  'Optional note for your caregiver...',
              border: OutlineInputBorder(),
            ),
          ),

          const SizedBox(height: 16),

          SizedBox(
            height: 56,
            child: FilledButton.icon(
              onPressed:
                  selectedMood == null
                      ? null
                      : _save,
              icon: const Icon(Icons.save_outlined),
              label: const Text(
                'Save My Feeling',
                style: TextStyle(fontSize: 17),
              ),
            ),
          ),

          if (previous != null) ...[
            const SizedBox(height: 18),
            Card(
              child: Padding(
                padding:
                    const EdgeInsets.all(18),
                child: Row(
                  children: [
                    const Icon(
                      Icons.history,
                      size: 30,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Your previous check-in: '
                        '${previous.mood}',
                        style: const TextStyle(
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _save() async {
    final mood =
        MoodOptions.all.firstWhere(
      (item) => item.id == selectedMood,
    );

    await MoodService.instance.addMood(
      MoodEntry(
        id: DateTime.now()
            .microsecondsSinceEpoch
            .toString(),
        patientId: patientId,
        createdAt: DateTime.now(),
        mood: mood.label,
        note: noteController.text.trim(),
      ),
    );

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Your feeling has been saved.',
        ),
      ),
    );

    Navigator.pop(context);
  }
}
