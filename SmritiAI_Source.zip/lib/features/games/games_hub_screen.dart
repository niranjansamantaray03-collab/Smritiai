
import 'package:flutter/material.dart';

import '../../core/auth/user_context.dart';
import 'game_catalog.dart';
import 'screens/memory_match_screen.dart';
import 'screens/pattern_sequence_screen.dart';
import 'screens/find_object_screen.dart';
import 'screens/number_memory_screen.dart';

class GamesHubScreen extends StatelessWidget {
  final String? patientId;

  const GamesHubScreen({
    super.key,
    this.patientId,
  });

  String get resolvedPatientId =>
      patientId ??
      UserContext.patientIdForCurrentUser ??
      'p1';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Cognitive Games'),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: GameCatalog.all.length,
        itemBuilder: (_, index) {
          final game = GameCatalog.all[index];

          return Card(
            margin: const EdgeInsets.only(bottom: 14),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => _openGame(context, game.id),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    Text(
                      game.icon,
                      style: const TextStyle(fontSize: 40),
                    ),
                    const SizedBox(width: 18),
                    Expanded(
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Text(
                            game.title,
                            style: const TextStyle(
                              fontSize: 21,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            game.description,
                            style: const TextStyle(fontSize: 16),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.chevron_right),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  void _openGame(BuildContext context, String gameId) {
    final pid = resolvedPatientId;

    Widget? screen;

    switch (gameId) {
      case 'memory_match':
        screen = MemoryMatchScreen(patientId: pid);
        break;
      case 'pattern_sequence':
        screen = PatternSequenceScreen(patientId: pid);
        break;
      case 'find_object':
        screen = FindObjectScreen(patientId: pid);
        break;
      case 'number_memory':
        screen = NumberMemoryScreen(patientId: pid);
        break;

      // These screens may have been created by an earlier phase.
      // If present, they are opened dynamically through named routes.
      case 'pattern_match':
        Navigator.pushNamed(
          context,
          '/patient/game/pattern-match',
          arguments: pid,
        );
        return;

      case 'find_difference':
        Navigator.pushNamed(
          context,
          '/patient/game/find-difference',
          arguments: pid,
        );
        return;
    }

    if (screen != null) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => screen!),
      );
    }
  }
}
