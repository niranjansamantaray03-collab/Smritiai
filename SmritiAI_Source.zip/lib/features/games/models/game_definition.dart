
class GameDefinition {
  final String id;
  final String name;
  final String description;
  final String icon;
  final int defaultQuestions;

  const GameDefinition({
    required this.id,
    required this.name,
    required this.description,
    required this.icon,
    this.defaultQuestions = 10,
  });
}
