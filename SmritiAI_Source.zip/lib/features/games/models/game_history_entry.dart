
class GameHistoryEntry {
  final String id;
  final String patientId;
  final String gameId;
  final String gameName;
  final DateTime playedAt;
  final int score;
  final int maxScore;
  final int correctAnswers;
  final int totalQuestions;
  final int durationSeconds;

  const GameHistoryEntry({
    required this.id,
    required this.patientId,
    required this.gameId,
    required this.gameName,
    required this.playedAt,
    required this.score,
    required this.maxScore,
    required this.correctAnswers,
    required this.totalQuestions,
    required this.durationSeconds,
  });

  double get accuracy {
    if (totalQuestions <= 0) return 0;
    return correctAnswers / totalQuestions;
  }

  double get percentage {
    if (maxScore <= 0) return 0;
    return (score / maxScore) * 100;
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'patient_id': patientId,
        'game_id': gameId,
        'game_name': gameName,
        'played_at': playedAt.toIso8601String(),
        'score': score,
        'max_score': maxScore,
        'correct_answers': correctAnswers,
        'total_questions': totalQuestions,
        'duration_seconds': durationSeconds,
      };

  factory GameHistoryEntry.fromMap(Map<String, dynamic> map) {
    return GameHistoryEntry(
      id: '${map['id']}',
      patientId: '${map['patient_id'] ?? ''}',
      gameId: '${map['game_id'] ?? ''}',
      gameName: '${map['game_name'] ?? ''}',
      playedAt: DateTime.tryParse('${map['played_at']}') ?? DateTime.now(),
      score: (map['score'] as num?)?.toInt() ?? 0,
      maxScore: (map['max_score'] as num?)?.toInt() ?? 0,
      correctAnswers: (map['correct_answers'] as num?)?.toInt() ?? 0,
      totalQuestions: (map['total_questions'] as num?)?.toInt() ?? 0,
      durationSeconds: (map['duration_seconds'] as num?)?.toInt() ?? 0,
    );
  }
}
