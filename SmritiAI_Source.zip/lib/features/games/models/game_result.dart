class GameResult {
  final String id;
  final String patientId;
  final String gameId;
  final String gameName;
  final DateTime playedAt;
  final int score;
  final int maxScore;
  final int durationSeconds;
  final int correctAnswers;
  final int totalQuestions;

  const GameResult({
    required this.id,
    required this.patientId,
    required this.gameId,
    required this.gameName,
    required this.playedAt,
    required this.score,
    required this.maxScore,
    required this.durationSeconds,
    required this.correctAnswers,
    required this.totalQuestions,
  });

  double get accuracy {
    if (totalQuestions == 0) return 0;
    return correctAnswers / totalQuestions;
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'patientId': patientId,
      'gameId': gameId,
      'gameName': gameName,
      'playedAt': playedAt.toIso8601String(),
      'score': score,
      'maxScore': maxScore,
      'durationSeconds': durationSeconds,
      'correctAnswers': correctAnswers,
      'totalQuestions': totalQuestions,
    };
  }
}
