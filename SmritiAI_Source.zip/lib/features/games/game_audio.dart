
import '../../services/audio_service.dart';

class GameAudio {
  GameAudio._();

  static final AudioService _audio = AudioService.instance;

  static Future<void> start() => _audio.playGameStart();
  static Future<void> correct() => _audio.playCorrect();
  static Future<void> wrong() => _audio.playWrong();
  static Future<void> complete() => _audio.playGameComplete();
}
