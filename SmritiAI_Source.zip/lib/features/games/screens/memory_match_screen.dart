import 'dart:async';

import 'package:flutter/material.dart';

import '../game_engine.dart';

class MemoryMatchScreen extends StatefulWidget {
  final String patientId;

  const MemoryMatchScreen({
    super.key,
    required this.patientId,
  });

  @override
  State<MemoryMatchScreen> createState() => _MemoryMatchScreenState();
}

class _MemoryMatchScreenState extends State<MemoryMatchScreen> {
  late List<String> cards;
  final List<int> revealed = [];
  final List<int> matched = [];

  int moves = 0;
  int pairsFound = 0;
  DateTime? startedAt;

  @override
  void initState() {
    super.initState();
    _newGame();
  }

  void _newGame() {
    final symbols = GameEngine.shuffledSymbols().take(6).toList();

    cards = [...symbols, ...symbols]..shuffle();

    revealed.clear();
    matched.clear();
    moves = 0;
    pairsFound = 0;
    startedAt = DateTime.now();

    setState(() {});
  }

  Future<void> _tapCard(int index) async {
    if (revealed.length >= 2 ||
        revealed.contains(index) ||
        matched.contains(index)) {
      return;
    }

    setState(() {
      revealed.add(index);
    });

    if (revealed.length == 2) {
      moves++;

      await Future.delayed(const Duration(milliseconds: 650));

      if (!mounted) return;

      final first = revealed[0];
      final second = revealed[1];

      if (cards[first] == cards[second]) {
        setState(() {
          matched.add(first);
          matched.add(second);
          revealed.clear();
          pairsFound++;
        });

        if (pairsFound == 6) {
          _completeGame();
        }
      } else {
        setState(() {
          revealed.clear();
        });
      }
    }
  }

  void _completeGame() {
    final seconds =
        DateTime.now().difference(startedAt!).inSeconds;

    final score = (600 - seconds * 3 - moves * 8)
        .clamp(100, 600);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('Well done! 🎉'),
        content: Text(
          'You found all the pairs.\n\n'
          'Moves: $moves\n'
          'Time: ${seconds}s\n'
          'Score: $score',
          style: const TextStyle(fontSize: 18),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Finish'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _newGame();
            },
            child: const Text('Play Again'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Memory Match'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            const Text(
              'Find all matching pairs',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Pairs found: $pairsFound / 6',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: GridView.builder(
                itemCount: cards.length,
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                itemBuilder: (_, index) {
                  final visible = revealed.contains(index) ||
                      matched.contains(index);

                  return InkWell(
                    borderRadius: BorderRadius.circular(18),
                    onTap: () => _tapCard(index),
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(18),
                        color: visible
                            ? Theme.of(context)
                                .colorScheme
                                .primaryContainer
                            : Theme.of(context)
                                .colorScheme
                                .surfaceContainerHighest,
                      ),
                      child: Center(
                        child: Text(
                          visible ? cards[index] : '?',
                          style: const TextStyle(fontSize: 42),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
