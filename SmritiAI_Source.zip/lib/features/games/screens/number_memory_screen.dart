import 'package:flutter/material.dart';

class NumberMemoryScreen extends StatefulWidget {
  final String patientId;

  const NumberMemoryScreen({
    super.key,
    required this.patientId,
  });

  @override
  State<NumberMemoryScreen> createState() =>
      _NumberMemoryScreenState();
}

class _NumberMemoryScreenState
    extends State<NumberMemoryScreen> {
  final TextEditingController controller =
      TextEditingController();

  String number = '482';
  bool visible = true;
  int round = 1;
  int score = 0;

  Future<void> _hideNumber() async {
    await Future.delayed(const Duration(seconds: 2));

    if (!mounted) return;

    setState(() {
      visible = false;
    });
  }

  void _check() {
    final correct = controller.text.trim() == number;

    if (correct) {
      score += number.length * 10;
    }

    if (round >= 5) {
      _finish();
      return;
    }

    round++;
    number = _generateNumber(round + 2);
    controller.clear();

    setState(() {
      visible = true;
    });

    WidgetsBinding.instance.addPostFrameCallback(
              (_) {
                if (mounted) {
                  _hideNumber();
                }
              },
            );
  }

  String _generateNumber(int length) {
    final now = DateTime.now().microsecondsSinceEpoch;
    final raw = now.toString();
    return raw.substring(raw.length - length);
  }

  void _finish() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('Number Memory Complete'),
        content: Text(
          'Score: $score',
          style: const TextStyle(fontSize: 21),
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Finish'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (visible && round == 1) {
      _hideNumber();
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Number Memory'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(25),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Round $round / 5',
              style: const TextStyle(fontSize: 22),
            ),
            const SizedBox(height: 30),
            const Text(
              'Remember this number:',
              style: TextStyle(fontSize: 22),
            ),
            const SizedBox(height: 20),
            Text(
              visible ? number : '••••',
              style: const TextStyle(
                fontSize: 48,
                fontWeight: FontWeight.bold,
                letterSpacing: 8,
              ),
            ),
            const SizedBox(height: 35),
            TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 28),
              decoration: const InputDecoration(
                hintText: 'Enter number',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: visible ? null : _check,
              child: const Text('Check Answer'),
            ),
            const SizedBox(height: 15),
            Text(
              'Score: $score',
              style: const TextStyle(fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }
}
