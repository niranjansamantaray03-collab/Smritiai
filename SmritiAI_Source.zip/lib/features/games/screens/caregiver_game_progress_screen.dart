
import 'package:flutter/material.dart';

import '../services/game_history_service.dart';
import '../../rudas/services/rudas_service.dart';

class CaregiverGameProgressScreen
    extends StatefulWidget {
  const CaregiverGameProgressScreen({
    super.key,
    required this.patientId,
  });

  final String patientId;

  @override
  State<CaregiverGameProgressScreen>
      createState() =>
          _CaregiverGameProgressScreenState();
}

class _CaregiverGameProgressScreenState
    extends State<
        CaregiverGameProgressScreen> {
  bool loading = true;

  int sessions = 0;
  double averageAccuracy = 0;
  int gamesPlayed = 0;
  int untilRudas = 7;

  List<Map<String, dynamic>>
      recent = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final history =
        await GameHistoryService.instance
            .getForPatient(
      widget.patientId,
    );

    final summary =
        await GameHistoryService.instance
            .summary(
      widget.patientId,
    );

    untilRudas =
        await RudasService.instance
            .sessionsUntilNextAssessment(
      widget.patientId,
    );

    recent = history
        .take(10)
        .map(
          (item) => {
            'game': item.gameName,
            'accuracy': item.accuracy,
            'score': item.score,
            'played':
                item.playedAt,
          },
        )
        .toList();

    sessions =
        summary['sessions'] as int? ??
            0;

    averageAccuracy =
        (summary['average_accuracy']
                as num?)
            ?.toDouble() ??
        0;

    gamesPlayed =
        summary['games_played'] as int? ??
            0;

    if (mounted) {
      setState(
        () => loading = false,
      );
    }
  }

  @override
  Widget build(
    BuildContext context,
  ) {
    if (loading) {
      return const Scaffold(
        body: Center(
          child:
              CircularProgressIndicator(),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Game Performance',
        ),
      ),
      body: ListView(
        padding:
            const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Expanded(
                child: _StatCard(
                  label: 'Sessions',
                  value:
                      '$sessions',
                ),
              ),
              const SizedBox(
                width: 10,
              ),
              Expanded(
                child: _StatCard(
                  label: 'Games',
                  value:
                      '$gamesPlayed',
                ),
              ),
              const SizedBox(
                width: 10,
              ),
              Expanded(
                child: _StatCard(
                  label: 'Average',
                  value:
                      '${(averageAccuracy * 100).round()}%',
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 16,
          ),
          Card(
            child: ListTile(
              leading: Icon(
                Icons.assessment,
                color: untilRudas == 0
                    ? Theme.of(context)
                        .colorScheme
                        .error
                    : null,
              ),
              title: Text(
                untilRudas == 0
                    ? 'RUDAS reassessment due'
                    : '$untilRudas sessions until RUDAS checkpoint',
              ),
              subtitle: const Text(
                'Game results are tracked separately from RUDAS.',
              ),
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          Text(
            'Recent sessions',
            style: Theme.of(
              context,
            )
                .textTheme
                .titleLarge,
          ),
          const SizedBox(
            height: 8,
          ),
          if (recent.isEmpty)
            const Card(
              child: Padding(
                padding:
                    EdgeInsets.all(20),
                child: Text(
                  'No completed game sessions yet.',
                ),
              ),
            )
          else
            ...recent.map(
              (item) => Card(
                child: ListTile(
                  title: Text(
                    item['game']
                        as String,
                  ),
                  subtitle: Text(
                    '${((item['accuracy'] as double) * 100).round()}% accuracy',
                  ),
                  trailing: Text(
                    '${item['score']}',
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Card(
      child: Padding(
        padding:
            const EdgeInsets.symmetric(
          vertical: 18,
          horizontal: 8,
        ),
        child: Column(
          children: [
            Text(
              value,
              style: Theme.of(context)
                  .textTheme
                  .titleLarge,
            ),
            const SizedBox(
              height: 4,
            ),
            Text(
              label,
              textAlign:
                  TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
