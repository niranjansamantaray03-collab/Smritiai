
import 'package:flutter/material.dart';

import '../../core/auth/user_context.dart';
import 'game_catalog.dart';
import 'screens/memory_match_screen.dart';
import 'screens/pattern_sequence_screen.dart';
import 'screens/find_object_screen.dart';
import 'screens/number_memory_screen.dart';

class GameLauncher {
  GameLauncher._();

  static Widget? screenFor(
    String gameId,
  ) {
    final patientId =
        UserContext.patientIdForCurrentUser ??
            'p1';

    switch (gameId) {
      case 'memory_match':
        return MemoryMatchScreen(
          patientId: patientId,
        );

      case 'pattern_sequence':
        return PatternSequenceScreen(
          patientId: patientId,
        );

      case 'find_object':
        return FindObjectScreen(
          patientId: patientId,
        );

      case 'number_memory':
        return NumberMemoryScreen(
          patientId: patientId,
        );

      case 'pattern_match':
      case 'find_difference':
        // If the dedicated screen was not created
        // in an earlier phase, keep the game visible
        // rather than sending the user to a broken route.
        return _ComingSoonGame(
          title:
              GameCatalog.byId(gameId)
                  ?.name ??
              'Game',
        );

      default:
        return null;
    }
  }
}

class _ComingSoonGame
    extends StatelessWidget {
  const _ComingSoonGame({
    required this.title,
  });

  final String title;

  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: Center(
        child: Padding(
          padding:
              const EdgeInsets.all(24),
          child: Column(
            mainAxisSize:
                MainAxisSize.min,
            children: [
              const Icon(
                Icons.extension_outlined,
                size: 64,
              ),
              const SizedBox(
                height: 16,
              ),
              Text(
                title,
                style: Theme.of(context)
                    .textTheme
                    .headlineSmall,
              ),
              const SizedBox(
                height: 8,
              ),
              const Text(
                'This game is registered in the SmritiAI game system and its dedicated gameplay screen will be connected in the final UI polish pass.',
                textAlign:
                    TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
