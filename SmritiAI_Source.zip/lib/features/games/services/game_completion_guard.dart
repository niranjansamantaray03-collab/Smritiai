
import 'package:shared_preferences/shared_preferences.dart';

class GameCompletionGuard {
  GameCompletionGuard._();

  static final GameCompletionGuard instance = GameCompletionGuard._();

  String _key(String sessionId) =>
      'smritiai_completed_game_session_$sessionId';

  Future<bool> claim(String sessionId) async {
    final prefs = await SharedPreferences.getInstance();
    final key = _key(sessionId);

    if (prefs.getBool(key) == true) {
      return false;
    }

    await prefs.setBool(key, true);
    return true;
  }
}
