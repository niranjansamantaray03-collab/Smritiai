
import '../models/game_history_entry.dart';
import '../../../data/persistence/persistence_manager.dart';
import '../../../data/sync/sync_manager.dart';

class GameHistoryService {
  GameHistoryService._();

  static final GameHistoryService
      instance =
      GameHistoryService._();

  final Map<String, GameHistoryEntry>
      _history = {};

  bool _loaded = false;

  Future<void> initialize() async {
    if (_loaded) return;

    final records =
        await PersistenceManager.instance
            .getAll('game_sessions');

    for (final record in records) {
      try {
        final entry =
            GameHistoryEntry.fromMap(
          record,
        );

        _history[entry.id] = entry;
      } catch (_) {}
    }

    _loaded = true;
  }

  Future<void> recordCompletedGame(
    GameHistoryEntry entry,
  ) async {
    await initialize();

    // Idempotency:
    // The same game session cannot be counted twice.
    if (_history.containsKey(entry.id)) {
      return;
    }

    _history[entry.id] = entry;

    await PersistenceManager.instance
        .save(
      'game_sessions',
      entry.id,
      entry.toMap(),
    );

    SyncManager.instance.queueRecord(
      collection: 'game_sessions',
      patientId: entry.patientId,
      operation: 'upsert',
      data: entry.toMap(),
    );
  }

  Future<List<GameHistoryEntry>>
      getForPatient(
    String patientId,
  ) async {
    await initialize();

    final result = _history.values
        .where(
          (entry) =>
              entry.patientId ==
              patientId,
        )
        .toList();

    result.sort(
      (a, b) => b.playedAt
          .compareTo(a.playedAt),
    );

    return result;
  }

  Future<List<GameHistoryEntry>>
      getForGame(
    String patientId,
    String gameId,
  ) async {
    final all =
        await getForPatient(
      patientId,
    );

    return all
        .where(
          (entry) =>
              entry.gameId ==
              gameId,
        )
        .toList();
  }

  Future<int> completedSessionCount(
    String patientId,
  ) async {
    final history =
        await getForPatient(
      patientId,
    );

    return history.length;
  }

  Future<Map<String, dynamic>>
      summary(
    String patientId,
  ) async {
    final history =
        await getForPatient(
      patientId,
    );

    if (history.isEmpty) {
      return {
        'sessions': 0,
        'average_accuracy': 0.0,
        'games_played': 0,
        'last_played': null,
      };
    }

    final accuracy =
        history.fold<double>(
      0,
      (sum, item) =>
          sum + item.accuracy,
    );

    final games =
        history
            .map(
              (item) => item.gameId,
            )
            .toSet()
            .length;

    return {
      'sessions': history.length,
      'average_accuracy':
          accuracy / history.length,
      'games_played': games,
      'last_played':
          history.first.playedAt
              .toIso8601String(),
    };
  }
}
