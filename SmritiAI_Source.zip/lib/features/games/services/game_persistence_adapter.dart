
import '../../../data/persistence/feature_write_service.dart';
import '../models/game_history_entry.dart';

class GamePersistenceAdapter {
  GamePersistenceAdapter._();

  static final GamePersistenceAdapter instance =
      GamePersistenceAdapter._();

  Future<void> save(GameHistoryEntry entry) {
    return FeatureWriteService.instance.saveGame(entry);
  }
}
