
import 'package:flutter/material.dart';
import '../../../core/auth/user_context.dart';
import '../services/task_service.dart';
import '../models/caregiver_task.dart';

class CaregiverAssignTaskScreen extends StatefulWidget {
  final String? patientId;

  const CaregiverAssignTaskScreen({
    super.key,
    this.patientId,
  });

  @override
  State<CaregiverAssignTaskScreen> createState() =>
      _CaregiverAssignTaskScreenState();
}

class _CaregiverAssignTaskScreenState
    extends State<CaregiverAssignTaskScreen> {
  final _title = TextEditingController();
  final _description = TextEditingController();

  DateTime _dueAt = DateTime.now().add(const Duration(hours: 1));
  String _priority = 'normal';
  String _category = 'general';

  String? get patientId =>
      widget.patientId ?? UserContext.patientIdForCaregiver;

  String get caregiverId =>
      UserContext.userId ?? 'c1';

  @override
  void dispose() {
    _title.dispose();
    _description.dispose();
    super.dispose();
  }

  Future<void> _pickTime() async {
    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_dueAt),
    );

    if (time == null) return;

    setState(() {
      _dueAt = DateTime(
        _dueAt.year,
        _dueAt.month,
        _dueAt.day,
        time.hour,
        time.minute,
      );
    });
  }

  void _assign() {
    final pid = patientId;

    if (pid == null || pid.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No patient is connected.')),
      );
      return;
    }

    if (_title.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a task title.')),
      );
      return;
    }

    TaskService.instance.assign(
      patientId: pid,
      caregiverId: caregiverId,
      title: _title.text,
      description: _description.text,
      dueAt: _dueAt,
      priority: _priority,
      category: _category,
    );

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Task assigned to patient.')),
    );

    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Assign Task'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(
            controller: _title,
            decoration: const InputDecoration(
              labelText: 'Task title',
              hintText: 'Example: Take medicine',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _description,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Instructions',
              hintText: 'Add simple instructions for the patient',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: _category,
            decoration: const InputDecoration(
              labelText: 'Category',
              border: OutlineInputBorder(),
            ),
            items: const [
              DropdownMenuItem(value: 'general', child: Text('General')),
              DropdownMenuItem(value: 'health', child: Text('Health')),
              DropdownMenuItem(value: 'activity', child: Text('Activity')),
              DropdownMenuItem(value: 'memory', child: Text('Memory')),
              DropdownMenuItem(value: 'appointment', child: Text('Appointment')),
            ],
            onChanged: (v) => setState(() => _category = v ?? 'general'),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: _priority,
            decoration: const InputDecoration(
              labelText: 'Priority',
              border: OutlineInputBorder(),
            ),
            items: const [
              DropdownMenuItem(value: 'low', child: Text('Low')),
              DropdownMenuItem(value: 'normal', child: Text('Normal')),
              DropdownMenuItem(value: 'high', child: Text('High')),
            ],
            onChanged: (v) => setState(() => _priority = v ?? 'normal'),
          ),
          const SizedBox(height: 16),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text(
              'Due time',
              style: TextStyle(fontSize: 18),
            ),
            subtitle: Text(_format(_dueAt)),
            trailing: FilledButton.tonal(
              onPressed: _pickTime,
              child: const Text('Change'),
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 60,
            child: FilledButton.icon(
              onPressed: _assign,
              icon: const Icon(Icons.assignment_turned_in),
              label: const Text(
                'Assign Task',
                style: TextStyle(fontSize: 19),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _format(DateTime d) {
    final hour = d.hour % 12 == 0 ? 12 : d.hour % 12;
    final minute = d.minute.toString().padLeft(2, '0');
    final suffix = d.hour >= 12 ? 'PM' : 'AM';
    return '$hour:$minute $suffix';
  }
}
