
class CaregiverTask {
  final String id;
  final String patientId;
  final String caregiverId;
  final String title;
  final String description;
  final DateTime dueAt;
  final bool completed;
  final DateTime? completedAt;
  final String priority;
  final String category;
  final DateTime createdAt;

  const CaregiverTask({
    required this.id,
    required this.patientId,
    required this.caregiverId,
    required this.title,
    required this.description,
    required this.dueAt,
    required this.completed,
    this.completedAt,
    this.priority = 'normal',
    this.category = 'general',
    required this.createdAt,
  });

  bool get isOverdue =>
      !completed && DateTime.now().isAfter(dueAt);

  bool get isDueToday {
    final now = DateTime.now();
    return now.year == dueAt.year &&
        now.month == dueAt.month &&
        now.day == dueAt.day;
  }

  CaregiverTask copyWith({
    String? id,
    String? patientId,
    String? caregiverId,
    String? title,
    String? description,
    DateTime? dueAt,
    bool? completed,
    DateTime? completedAt,
    String? priority,
    String? category,
    DateTime? createdAt,
    bool clearCompletedAt = false,
  }) {
    return CaregiverTask(
      id: id ?? this.id,
      patientId: patientId ?? this.patientId,
      caregiverId: caregiverId ?? this.caregiverId,
      title: title ?? this.title,
      description: description ?? this.description,
      dueAt: dueAt ?? this.dueAt,
      completed: completed ?? this.completed,
      completedAt: clearCompletedAt ? null : (completedAt ?? this.completedAt),
      priority: priority ?? this.priority,
      category: category ?? this.category,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'patient_id': patientId,
        'caregiver_id': caregiverId,
        'title': title,
        'description': description,
        'due_at': dueAt.toIso8601String(),
        'completed': completed,
        'completed_at': completedAt?.toIso8601String(),
        'priority': priority,
        'category': category,
        'created_at': createdAt.toIso8601String(),
      };

  factory CaregiverTask.fromMap(Map<String, dynamic> map) {
    return CaregiverTask(
      id: '${map['id']}',
      patientId: '${map['patient_id'] ?? map['patientId']}',
      caregiverId: '${map['caregiver_id'] ?? map['caregiverId']}',
      title: '${map['title'] ?? ''}',
      description: '${map['description'] ?? ''}',
      dueAt: DateTime.tryParse('${map['due_at'] ?? map['dueAt']}') ??
          DateTime.now(),
      completed: map['completed'] == true,
      completedAt: map['completed_at'] == null
          ? null
          : DateTime.tryParse('${map['completed_at']}'),
      priority: '${map['priority'] ?? 'normal'}',
      category: '${map['category'] ?? 'general'}',
      createdAt: DateTime.tryParse('${map['created_at'] ?? ''}') ??
          DateTime.now(),
    );
  }
}
