
import '../models/caregiver_task.dart';
import '../../../core/auth/user_context.dart';

class TaskService {
  TaskService._();

  static final TaskService instance = TaskService._();

  final Map<String, List<CaregiverTask>> _tasksByPatient = {};

  List<CaregiverTask> getTasksForPatient(String patientId) {
    final list = List<CaregiverTask>.from(
      _tasksByPatient[patientId] ?? const [],
    );
    list.sort((a, b) => a.dueAt.compareTo(b.dueAt));
    return list;
  }

  List<CaregiverTask> getCurrentPatientTasks() {
    final patientId = UserContext.patientIdForCurrentUser;
    if (patientId == null || patientId.isEmpty) return [];
    return getTasksForPatient(patientId);
  }

  void seedForPatientIfNeeded(String patientId, String caregiverId) {
    if (_tasksByPatient.containsKey(patientId)) return;

    final now = DateTime.now();

    _tasksByPatient[patientId] = [
      CaregiverTask(
        id: 'task-$patientId-1',
        patientId: patientId,
        caregiverId: caregiverId,
        title: 'Drink some water',
        description: 'Have a glass of water.',
        dueAt: now.add(const Duration(hours: 1)),
        completed: false,
        priority: 'normal',
        category: 'health',
        createdAt: now,
      ),
      CaregiverTask(
        id: 'task-$patientId-2',
        patientId: patientId,
        caregiverId: caregiverId,
        title: 'Take a short walk',
        description: 'Take a gentle 10 minute walk if comfortable.',
        dueAt: now.add(const Duration(hours: 3)),
        completed: false,
        priority: 'normal',
        category: 'activity',
        createdAt: now,
      ),
    ];
  }

  CaregiverTask assign({
    required String patientId,
    required String caregiverId,
    required String title,
    required String description,
    required DateTime dueAt,
    String priority = 'normal',
    String category = 'general',
  }) {
    final task = CaregiverTask(
      id: 'task-${DateTime.now().microsecondsSinceEpoch}',
      patientId: patientId,
      caregiverId: caregiverId,
      title: title.trim(),
      description: description.trim(),
      dueAt: dueAt,
      completed: false,
      priority: priority,
      category: category,
      createdAt: DateTime.now(),
    );

    (_tasksByPatient[patientId] ??= []).add(task);
    return task;
  }

  bool complete(String patientId, String taskId) {
    final list = _tasksByPatient[patientId];
    if (list == null) return false;

    final index = list.indexWhere((t) => t.id == taskId);
    if (index < 0) return false;

    list[index] = list[index].copyWith(
      completed: true,
      completedAt: DateTime.now(),
    );
    return true;
  }

  bool reopen(String patientId, String taskId) {
    final list = _tasksByPatient[patientId];
    if (list == null) return false;

    final index = list.indexWhere((t) => t.id == taskId);
    if (index < 0) return false;

    list[index] = list[index].copyWith(
      completed: false,
      clearCompletedAt: true,
    );
    return true;
  }

  bool delete(String patientId, String taskId) {
    final list = _tasksByPatient[patientId];
    if (list == null) return false;

    final before = list.length;
    list.removeWhere((t) => t.id == taskId);
    return list.length != before;
  }

  List<CaregiverTask> pending(String patientId) =>
      getTasksForPatient(patientId).where((t) => !t.completed).toList();

  List<CaregiverTask> completed(String patientId) =>
      getTasksForPatient(patientId).where((t) => t.completed).toList();

  int completedCount(String patientId) =>
      completed(patientId).length;

  int totalCount(String patientId) =>
      getTasksForPatient(patientId).length;

  double completionRate(String patientId) {
    final total = totalCount(patientId);
    if (total == 0) return 0;
    return completedCount(patientId) / total;
  }

  int overdueCount(String patientId) =>
      getTasksForPatient(patientId).where((t) => t.isOverdue).length;
}
