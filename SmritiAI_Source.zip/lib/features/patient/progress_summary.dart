class ProgressSummary {
  final int gamesPlayed;
  final int tasksCompleted;
  final int memoriesCreated;
  final int rudasAssessments;
  final int moodEntries;

  const ProgressSummary({
    this.gamesPlayed = 0,
    this.tasksCompleted = 0,
    this.memoriesCreated = 0,
    this.rudasAssessments = 0,
    this.moodEntries = 0,
  });
}
