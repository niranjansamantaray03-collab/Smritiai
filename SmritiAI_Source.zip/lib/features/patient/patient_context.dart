
import '../../core/auth/user_context.dart';

class PatientContext {
  PatientContext._();

  static String get patientId => UserContext.userId;

  static String get patientName => UserContext.displayName;

  static String get language => UserContext.language;
}
