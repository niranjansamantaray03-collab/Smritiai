
import '../../services/audio_service.dart';

class PatientAudioSettings {
  PatientAudioSettings._();

  static final AudioService audio = AudioService.instance;

  static void setMusicEnabled(bool enabled) {
    audio.musicEnabled = enabled;
    if (!enabled) {
      audio.stopMusic();
    }
  }

  static void setEffectsEnabled(bool enabled) {
    audio.effectsEnabled = enabled;
  }
}
