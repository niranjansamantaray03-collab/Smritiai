
import 'package:flutter/material.dart';

import '../../../core/auth/user_context.dart';
import '../../caregiver/services/patient_connection_service.dart';

class PatientConnectionCodeScreen extends StatefulWidget {
  const PatientConnectionCodeScreen({super.key});

  @override
  State<PatientConnectionCodeScreen> createState() =>
      _PatientConnectionCodeScreenState();
}

class _PatientConnectionCodeScreenState
    extends State<PatientConnectionCodeScreen> {
  bool _loading = true;
  String? _code;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadCode();
  }

  Future<void> _loadCode() async {
    final patientId = UserContext.userId;

    if (patientId == null || patientId.isEmpty) {
      setState(() {
        _loading = false;
        _error = 'Patient session is not available.';
      });
      return;
    }

    try {
      final code = await PatientConnectionService.instance
          .generatePatientCode(patientId: patientId);

      if (!mounted) return;

      setState(() {
        _code = code;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Connection Code'),
      ),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: _loading
                ? const CircularProgressIndicator()
                : _error != null
                    ? Text(
                        _error!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 20),
                      )
                    : Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.verified_user_outlined,
                            size: 80,
                          ),
                          const SizedBox(height: 24),
                          const Text(
                            'Give this code to your caregiver',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 24),
                          SelectableText(
                            _code!,
                            style: const TextStyle(
                              fontSize: 42,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 7,
                            ),
                          ),
                          const SizedBox(height: 20),
                          const Text(
                            'Your caregiver can use this code to connect '
                            'to your SmritiAI account.',
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 18),
                          ),
                        ],
                      ),
          ),
        ),
      ),
    );
  }
}
