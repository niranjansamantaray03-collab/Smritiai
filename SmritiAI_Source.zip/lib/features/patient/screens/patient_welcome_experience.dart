
import 'package:flutter/material.dart';

import '../../../services/audio_service.dart';
import '../../language/app_language.dart';
import '../../language/language_service.dart';
import '../../voice/services/voice_service.dart';

class PatientWelcomeExperience
    extends StatefulWidget {
  final VoidCallback onContinue;

  const PatientWelcomeExperience({
    super.key,
    required this.onContinue,
  });

  @override
  State<PatientWelcomeExperience> createState() =>
      _PatientWelcomeExperienceState();
}

class _PatientWelcomeExperienceState
    extends State<PatientWelcomeExperience> {

  bool musicOn = true;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance
        .addPostFrameCallback((_) async {
      await AudioService.instance
          .playWelcomeMusic();

      await VoiceService.instance.speak(
        LanguageService.instance.text('welcome'),
        locale: LanguageService.instance
            .language
            .voiceLocale,
      );
    });
  }

  @override
  void dispose() {
    AudioService.instance.stopMusic();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final language =
        LanguageService.instance.language;

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(26),
            child: Column(
              mainAxisAlignment:
                  MainAxisAlignment.center,
              children: [
                const SizedBox(height: 20),

                const CircleAvatar(
                  radius: 52,
                  child: Icon(
                    Icons.psychology_alt_outlined,
                    size: 58,
                  ),
                ),

                const SizedBox(height: 22),

                const Text(
                  'SmritiAI',
                  style: TextStyle(
                    fontSize: 38,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 8),

                Text(
                  language == AppLanguage.english
                      ? 'Memories • Care • Connection'
                      : language ==
                              AppLanguage.hindi
                          ? 'यादें • देखभाल • जुड़ाव'
                          : 'आठवणी • काळजी • नाते',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 17,
                  ),
                ),

                const SizedBox(height: 35),

                Card(
                  child: Padding(
                    padding:
                        const EdgeInsets.all(22),
                    child: Column(
                      children: [
                        const Icon(
                          Icons.music_note,
                          size: 42,
                        ),
                        const SizedBox(height: 12),
                        Text(
                          language ==
                                  AppLanguage.english
                              ? 'A familiar musical welcome'
                              : language ==
                                      AppLanguage.hindi
                                  ? 'परिचित संगीत के साथ स्वागत'
                                  : 'परिचित संगीतासह स्वागत',
                          textAlign:
                              TextAlign.center,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight:
                                FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          language ==
                                  AppLanguage.english
                              ? 'Gentle instrumental music can play '
                                  'when the patient enters the app.'
                              : language ==
                                      AppLanguage.hindi
                                  ? 'ऐप खोलते समय हल्का संगीत चल सकता है।'
                                  : 'अॅप उघडताना हलके संगीत वाजू शकते.',
                          textAlign:
                              TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 18),

                OutlinedButton.icon(
                  onPressed: () async {
                    if (musicOn) {
                      await AudioService.instance
                          .stopMusic();
                    } else {
                      await AudioService.instance
                          .playWelcomeMusic();
                    }

                    setState(() {
                      musicOn = !musicOn;
                    });
                  },
                  icon: Icon(
                    musicOn
                        ? Icons.volume_up
                        : Icons.volume_off,
                  ),
                  label: Text(
                    musicOn
                        ? 'Music On'
                        : 'Music Off',
                  ),
                ),

                const SizedBox(height: 18),

                SizedBox(
                  width: double.infinity,
                  height: 58,
                  child: FilledButton(
                    onPressed: widget.onContinue,
                    child: Text(
                      language ==
                              AppLanguage.english
                          ? 'Continue'
                          : language ==
                                  AppLanguage.hindi
                              ? 'आगे बढ़ें'
                              : 'पुढे चला',
                      style: const TextStyle(
                        fontSize: 18,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 14),

                TextButton(
                  onPressed: () async {
                    await AudioService.instance
                        .stopMusic();
                    widget.onContinue();
                  },
                  child: const Text(
                    'Skip welcome music',
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
