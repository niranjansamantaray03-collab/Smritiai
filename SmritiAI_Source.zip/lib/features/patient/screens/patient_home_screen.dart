
import 'package:flutter/material.dart';

import '../../../core/auth/user_context.dart';
import '../../../core/constants/accessibility.dart';
import '../../../widgets/smriti_ui.dart';

class PatientHomeScreen extends StatelessWidget {
  const PatientHomeScreen({
    super.key,
    this.patientId,
  });

  final String? patientId;

  String get effectivePatientId =>
      patientId ??
      UserContext.patientIdForCurrentUser ??
      'p1';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SmritiAI'),
        actions: [
          IconButton(
            tooltip: 'Settings',
            icon: const Icon(
              Icons.settings_outlined,
              size: 28,
            ),
            onPressed: () {
              Navigator.pushNamed(
                context,
                '/language-voice',
              );
            },
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(
            SmritiAccessibility.pagePadding,
          ),
          children: [
            Text(
              'Hello 👋',
              style: Theme.of(context)
                  .textTheme
                  .headlineMedium,
            ),
            const SizedBox(height: 6),
            const Text(
              'What would you like to do?',
              style: TextStyle(
                fontSize:
                    SmritiAccessibility.patientBody,
              ),
            ),
            const SizedBox(height: 22),

            SmritiPatientCard(
              icon: Icons.task_alt_rounded,
              title: 'My Tasks',
              subtitle:
                  'See what I need to do today',
              onTap: () {
                Navigator.pushNamed(
                  context,
                  '/patient/tasks',
                );
              },
            ),

            SmritiPatientCard(
              icon: Icons.extension_rounded,
              title: 'Play Games',
              subtitle:
                  'Fun activities for the mind',
              onTap: () {
                Navigator.pushNamed(
                  context,
                  '/patient/games',
                );
              },
            ),

            SmritiPatientCard(
              icon: Icons.photo_album_rounded,
              title: 'My Memories',
              subtitle:
                  'Photos, stories and familiar people',
              onTap: () {
                Navigator.pushNamed(
                  context,
                  '/patient/memories',
                );
              },
            ),

            SmritiPatientCard(
              icon: Icons.favorite_rounded,
              title: 'How Am I Feeling?',
              subtitle:
                  'Tell us how you feel today',
              onTap: () {
                Navigator.pushNamed(
                  context,
                  '/patient/mood',
                );
              },
            ),

            SmritiPatientCard(
              icon: Icons.notifications_active_rounded,
              title: 'Reminders',
              subtitle:
                  'Important things to remember',
              onTap: () {
                Navigator.pushNamed(
                  context,
                  '/patient/reminders',
                );
              },
            ),

            SmritiPatientCard(
              icon: Icons.insights_rounded,
              title: 'My Progress',
              subtitle:
                  'See my activities and RUDAS',
              onTap: () {
                Navigator.pushNamed(
                  context,
                  '/patient/progress',
                );
              },
            ),

            const SizedBox(height: 12),

            Card(
              child: Padding(
                padding:
                    const EdgeInsets.all(18),
                child: Row(
                  children: [
                    const Icon(
                      Icons.shield_outlined,
                      size: 30,
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text(
                        'SmritiAI supports memory care and daily routines. It does not diagnose medical conditions.',
                        style: TextStyle(
                          fontSize:
                              SmritiAccessibility.patientSmall,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar:
          NavigationBar(
        selectedIndex: 0,
        onDestinationSelected: (index) {
          if (index == 1) {
            Navigator.pushNamed(
              context,
              '/patient/tasks',
            );
          } else if (index == 2) {
            Navigator.pushNamed(
              context,
              '/patient/games',
            );
          } else if (index == 3) {
            Navigator.pushNamed(
              context,
              '/patient/memories',
            );
          }
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon:
                Icon(Icons.home),
            label: 'Home',
          ),
          NavigationDestination(
            icon:
                Icon(Icons.task_outlined),
            label: 'Tasks',
          ),
          NavigationDestination(
            icon: Icon(
                Icons.extension_outlined),
            label: 'Games',
          ),
          NavigationDestination(
            icon: Icon(
                Icons.photo_album_outlined),
            label: 'Memories',
          ),
        ],
      ),
    );
  }
}
