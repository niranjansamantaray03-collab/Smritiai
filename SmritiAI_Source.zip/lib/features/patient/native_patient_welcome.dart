
import 'package:flutter/material.dart';

import '../../core/device/smriti_device_actions.dart';
import '../language/app_language.dart';
import '../voice/voice_locale.dart';

class NativePatientWelcome extends StatefulWidget {
  final AppLanguage language;

  const NativePatientWelcome({
    super.key,
    this.language = AppLanguage.english,
  });

  @override
  State<NativePatientWelcome> createState() =>
      _NativePatientWelcomeState();
}

class _NativePatientWelcomeState
    extends State<NativePatientWelcome> {

  bool started = false;

  VoiceLocale get locale {
    switch (widget.language) {
      case AppLanguage.english:
        return VoiceLocale.english;
      case AppLanguage.hindi:
        return VoiceLocale.hindi;
      case AppLanguage.marathi:
        return VoiceLocale.marathi;
    }
  }

  String get message {
    switch (widget.language) {
      case AppLanguage.english:
        return 'Welcome to SmritiAI. Take your time. You are safe here.';
      case AppLanguage.hindi:
        return 'स्मृति एआई में आपका स्वागत है। आराम से कीजिए। आप यहाँ सुरक्षित हैं।';
      case AppLanguage.marathi:
        return 'स्मृती एआय मध्ये आपले स्वागत आहे. आरामात करा. आपण येथे सुरक्षित आहात.';
    }
  }

  Future<void> _start() async {
    setState(() => started = true);

    await SmritiDeviceActions.instance.startWelcomeMusic();

    await SmritiDeviceActions.instance.speak(
      message,
      locale: locale,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(
              Icons.favorite_outline,
              size: 60,
            ),
            const SizedBox(height: 12),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 21,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _start,
                icon: Icon(
                  started
                      ? Icons.volume_up
                      : Icons.play_arrow,
                ),
                label: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Text(
                    started
                        ? 'Welcome started'
                        : 'Start welcome',
                    style: const TextStyle(
                      fontSize: 18,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
