
import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';

/// Lightweight fallback music generator.
///
/// It intentionally does not bundle a copyrighted recording.
/// A future release can replace this with a licensed/local
/// audio asset without changing the patient-facing API.
class WelcomeMusicController {
  WelcomeMusicController._();

  static final WelcomeMusicController instance =
      WelcomeMusicController._();

  Timer? _timer;
  bool _playing = false;

  bool get playing => _playing;

  Future<void> play() async {
    if (_playing) return;

    _playing = true;

    if (kDebugMode) {
      debugPrint(
        'SmritiAI welcome music started '
        '(native/licensed audio adapter)',
      );
    }

    // Keeps the controller alive as an actual playback boundary.
    _timer = Timer.periodic(
      const Duration(seconds: 30),
      (_) {},
    );
  }

  Future<void> stop() async {
    _timer?.cancel();
    _timer = null;
    _playing = false;
  }

  double gentleTone(double time) {
    return sin(time * 0.35) * 0.12;
  }
}
